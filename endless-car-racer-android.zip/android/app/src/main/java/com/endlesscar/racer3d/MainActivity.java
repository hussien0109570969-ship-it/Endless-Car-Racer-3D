package com.endlesscar.racer3d;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

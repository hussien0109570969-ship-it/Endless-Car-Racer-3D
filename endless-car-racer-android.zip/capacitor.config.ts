import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.endlesscar.racer3d",
  appName: "Endless Car Racer 3D",
  webDir: "dist-mobile",
  android: {
    allowMixedContent: false,
  },
  server: {
    androidScheme: "https",
    // no `url` = fully offline, loads bundled assets from the APK
  },
};

export default config;

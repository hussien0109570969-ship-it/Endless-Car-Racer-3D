import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useState } from "react";

const Game = lazy(() => import("../game/App"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Endless Car Racer 3D" },
      { name: "description", content: "Endless 3D car racing arcade game with multiple cars and roads." },
      { property: "og:title", content: "Endless Car Racer 3D" },
      { property: "og:description", content: "Endless 3D car racing arcade game with multiple cars and roads." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) {
    return <div className="flex min-h-screen items-center justify-center bg-black text-white">Loading…</div>;
  }
  return (
    <Suspense fallback={<div className="flex min-h-screen items-center justify-center bg-black text-white">Loading…</div>}>
      <Game />
    </Suspense>
  );
}

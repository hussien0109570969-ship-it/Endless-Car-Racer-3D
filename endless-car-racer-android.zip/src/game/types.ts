/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CarConfig {
  id: string;
  name: string;
  type: 'sports' | 'muscle' | 'supercar' | 'classic';
  color: string;
  secondaryColor: string;
  rimColor: string;
  speed: number;       // Max speed multiplier
  handling: number;    // Sensitivity multiplier
  acceleration: number;// How fast it reaches max speed
  description: string;
  price: number;       // Price in Coins (0 for free basic car)
  glowingNeon?: string; // Hex color for neon underglow, if any
  hasSpoiler?: boolean;
  hasSupercharger?: boolean;
  hasOpenTop?: boolean;
  isAngular?: boolean; // CyberTruck style
  isF1?: boolean; // F1 open wheel style
}

export interface RoadConfig {
  id: string;
  name: string;
  groundColor: string;
  laneColor: string;
  skyColor: string;
  ambientLightColor: string;
  sunColor: string;
  fogColor: string;
  fogDensity: number;
  decorations: 'desert' | 'snow' | 'night' | 'city' | 'mountain' | 'forest';
  description: string;
}

export interface GameSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  sensitivity: number; // 0.5 to 2.0
  graphicsQuality: 'low' | 'medium' | 'high';
}

export interface ScoreRecord {
  score: number;
  distance: number;
  date: string;
  carId: string;
  roadId: string;
}

export const CARS: CarConfig[] = [
  {
    id: 'miata_na',
    name: 'Miata NA',
    type: 'classic',
    color: '#cc1122',
    secondaryColor: '#ffffff',
    rimColor: '#dddddd',
    speed: 68,
    handling: 95,
    acceleration: 64,
    description: 'Extremely lightweight, agile roadster with cute active pop-up headlights.',
    price: 0,
    hasOpenTop: true
  },
  {
    id: 'el_camino',
    name: 'El Camino',
    type: 'muscle',
    color: '#2d5a27',
    secondaryColor: '#dddddd',
    rimColor: '#888888',
    speed: 72,
    handling: 70,
    acceleration: 75,
    description: 'Iconic classic utility muscle car with a durable chassis.',
    price: 500
  },
  {
    id: 'corvette_c3',
    name: 'Corvette C3',
    type: 'classic',
    color: '#8b0000',
    secondaryColor: '#111111',
    rimColor: '#ffffff',
    speed: 75,
    handling: 78,
    acceleration: 72,
    description: 'Stingray body shape with a long sweeping hood and elegant vintage cockpit.',
    price: 1000
  },
  {
    id: 'cybertruck',
    name: 'CyberTruck',
    type: 'muscle',
    color: '#a0a0a0',
    secondaryColor: '#ff2200',
    rimColor: '#111111',
    speed: 76,
    handling: 74,
    acceleration: 92,
    description: 'Angular armored stainless steel fortress. Bulletproof design, neon lightbars.',
    price: 1500,
    isAngular: true,
    glowingNeon: '#ff0000'
  },
  {
    id: 'retro_911',
    name: 'Retro 911',
    type: 'classic',
    color: '#ff5500',
    secondaryColor: '#222222',
    rimColor: '#aaaaaa',
    speed: 78,
    handling: 92,
    acceleration: 75,
    description: 'Timeless silhouette with a rear-engine weight distribution and whale tail.',
    price: 2000,
    hasSpoiler: true
  },
  {
    id: 'charger_70',
    name: 'Charger 70',
    type: 'muscle',
    color: '#1a1a1a',
    secondaryColor: '#e6a100',
    rimColor: '#ffbf00',
    speed: 80,
    handling: 65,
    acceleration: 90,
    description: 'Vintage high-horsepower beast featuring an aggressive hood supercharger.',
    price: 2500,
    hasSupercharger: true
  },
  {
    id: 'monza_sp',
    name: 'Monza SP',
    type: 'classic',
    color: '#d4af37',
    secondaryColor: '#1a1a1a',
    rimColor: '#ffffff',
    speed: 82,
    handling: 88,
    acceleration: 84,
    description: 'Premium open-top speedster combining vintage class with modern performance.',
    price: 3000,
    hasOpenTop: true
  },
  {
    id: 'mustang_boss',
    name: 'Mustang Boss',
    type: 'muscle',
    color: '#ffcc00',
    secondaryColor: '#111111',
    rimColor: '#222222',
    speed: 82,
    handling: 72,
    acceleration: 84,
    description: 'Stiff racing suspension and a rumbling classic American V8 muscle look.',
    price: 3500
  },
  {
    id: 'vantage',
    name: 'Vantage',
    type: 'sports',
    color: '#004225',
    secondaryColor: '#ffffff',
    rimColor: 'silver',
    speed: 84,
    handling: 86,
    acceleration: 82,
    description: 'Elegant British sports car balancing pure luxury with high speed dynamics.',
    price: 4000
  },
  {
    id: 'viper_gts',
    name: 'Viper GTS',
    type: 'sports',
    color: '#e60000',
    secondaryColor: '#ffffff',
    rimColor: '#cccccc',
    speed: 85,
    handling: 85,
    acceleration: 80,
    description: 'Classic high-performance racer with iconic white racing stripes.',
    price: 4500
  },
  {
    id: 'gtr_r34',
    name: 'GTR R34',
    type: 'sports',
    color: '#0055ff',
    secondaryColor: '#00ffff',
    rimColor: '#444444',
    speed: 88,
    handling: 89,
    acceleration: 87,
    description: 'The street racing king. Incredible AWD handling and double-deck spoiler.',
    price: 5000,
    hasSpoiler: true
  },
  {
    id: 'apex_predator',
    name: 'Apex Predator',
    type: 'supercar',
    color: '#00f0ff',
    secondaryColor: '#121212',
    rimColor: '#00f0ff',
    speed: 95,
    handling: 90,
    acceleration: 98,
    description: 'Sleek futuristic design with custom cyber neon underglow.',
    price: 6000,
    glowingNeon: '#00f0ff',
    hasSpoiler: true
  },
  {
    id: 'roadster_v2',
    name: 'Roadster V2',
    type: 'supercar',
    color: '#ffffff',
    secondaryColor: '#ff0055',
    rimColor: '#111111',
    speed: 97,
    handling: 96,
    acceleration: 100,
    description: 'Zero-emission electric rocket with unparalleled off-the-line acceleration.',
    price: 7500,
    hasOpenTop: true,
    glowingNeon: '#ff0055'
  },
  {
    id: 'phantom_gt',
    name: 'Phantom GT',
    type: 'supercar',
    color: '#111111',
    secondaryColor: '#ffd700',
    rimColor: '#ffd700',
    speed: 98,
    handling: 88,
    acceleration: 95,
    description: 'Stealth-black luxury hypercar with gold trim and extreme downforce.',
    price: 9000,
    glowingNeon: '#ffd700',
    hasSpoiler: true
  },
  {
    id: 'centenario',
    name: 'Centenario',
    type: 'supercar',
    color: '#3a3a3a',
    secondaryColor: '#ffff00',
    rimColor: '#ffff00',
    speed: 99,
    handling: 94,
    acceleration: 99,
    description: 'V12 carbon-fiber track weapon with low stance and maximum speed.',
    price: 11000,
    glowingNeon: '#ffff00',
    hasSpoiler: true
  },
  {
    id: 'f1_legend',
    name: 'F1 Legend',
    type: 'supercar',
    color: '#e60000',
    secondaryColor: '#ffffff',
    rimColor: '#111111',
    speed: 100,
    handling: 100,
    acceleration: 97,
    description: 'Open-wheel single seater racing legend. Perfection in aerodynamics.',
    price: 15000,
    isF1: true,
    hasSpoiler: true
  }
];

export const ROADS: RoadConfig[] = [
  {
    id: 'desert',
    name: 'Desert Highway',
    groundColor: '#e2a85c',
    laneColor: '#ffffff',
    skyColor: '#ffcca0',
    ambientLightColor: '#ffeedd',
    sunColor: '#ffddaa',
    fogColor: '#fcd3a1',
    fogDensity: 0.003,
    decorations: 'desert',
    description: 'Drive through wide sandy horizons, giant saguaro cacti, and dry golden dunes.'
  },
  {
    id: 'snow',
    name: 'Snowy Blizzard',
    groundColor: '#eef2f7',
    laneColor: '#3a7bd5',
    skyColor: '#c0d3eb',
    ambientLightColor: '#d6e4f0',
    sunColor: '#ffffff',
    fogColor: '#dae5f2',
    fogDensity: 0.007,
    decorations: 'snow',
    description: 'Steer through icy roads, snow-capped pines, and cold misty winter wonderlands.'
  },
  {
    id: 'night',
    name: 'Cyber Neon Night',
    groundColor: '#0a0b10',
    laneColor: '#00ffff',
    skyColor: '#030510',
    ambientLightColor: '#101428',
    sunColor: '#ff00ff',
    fogColor: '#050612',
    fogDensity: 0.006,
    decorations: 'night',
    description: 'Race under the starry skies guided by bright glowing highway streetlamps and billboards.'
  },
  {
    id: 'city',
    name: 'Metropolis Expressway',
    groundColor: '#2b2d35',
    laneColor: '#ffaa00',
    skyColor: '#a0c0ff',
    ambientLightColor: '#ffffff',
    sunColor: '#ffffea',
    fogColor: '#b4cbf0',
    fogDensity: 0.004,
    decorations: 'city',
    description: 'Blast past towering urban concrete skyscrapers, dynamic advertisements, and city towers.'
  },
  {
    id: 'mountain',
    name: 'Red Canyon Ridge',
    groundColor: '#4d463f',
    laneColor: '#ffffea',
    skyColor: '#ffa07a',
    ambientLightColor: '#ffd1b3',
    sunColor: '#ff7733',
    fogColor: '#f79f79',
    fogDensity: 0.005,
    decorations: 'mountain',
    description: 'Carve around sharp red rocky canyons, arching tunnels, and mountain ridges at dusk.'
  },
  {
    id: 'forest',
    name: 'Deep Redwood Forest',
    groundColor: '#1d2a1a',
    laneColor: '#ffffff',
    skyColor: '#8da87e',
    ambientLightColor: '#c2d1b2',
    sunColor: '#ffffcc',
    fogColor: '#90aa82',
    fogDensity: 0.006,
    decorations: 'forest',
    description: 'Dodge redwood tree trunks, ferns, and mossy rock formations in a dense evergreen canopy.'
  }
];

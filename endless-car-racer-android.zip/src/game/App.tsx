/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { MainMenu } from './components/MainMenu';
import { GameHUD } from './components/GameHUD';
import { GameOver } from './components/GameOver';
import { GameSettings } from './types';
import { soundManager } from './soundManager';
import { Smartphone, Monitor, ShieldAlert, Award } from 'lucide-react';

export default function App() {
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'gameover' | 'paused'>('menu');
  
  // Persistent States
  const [selectedCarId, setSelectedCarId] = useState<string>(() => {
    return localStorage.getItem('endless_car_racer_car') || 'miata_na';
  });

  const [selectedRoadId, setSelectedRoadId] = useState<string>(() => {
    return localStorage.getItem('endless_car_racer_road') || 'desert';
  });

  const [highScore, setHighScore] = useState<number>(() => {
    const saved = localStorage.getItem('endless_car_racer_highscore');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [lastScore, setLastScore] = useState<number>(() => {
    const saved = localStorage.getItem('endless_car_racer_lastscore');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [settings, setSettings] = useState<GameSettings>(() => {
    const saved = localStorage.getItem('endless_car_racer_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      soundEnabled: true,
      musicEnabled: true,
      sensitivity: 1.0,
      graphicsQuality: 'high'
    };
  });

  // Coins & Shop Persistence
  const [coins, setCoins] = useState<number>(() => {
    const saved = localStorage.getItem('endless_car_racer_coins');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [unlockedCarIds, setUnlockedCarIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('endless_car_racer_unlocked_cars');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return ['miata_na']; // miata_na is free
  });

  const [coinsEarnedLastRound, setCoinsEarnedLastRound] = useState<number>(0);

  // Gameplay HUD and mechanics states
  const [currentScore, setCurrentScore] = useState<number>(0);
  const [currentSpeed, setCurrentSpeed] = useState<number>(0);
  const [distanceTravelled, setDistanceTravelled] = useState<number>(0);
  const [isNewRecord, setIsNewRecord] = useState<boolean>(false);
  
  const [coinsCollectedThisRound, setCoinsCollectedThisRound] = useState<number>(0);
  const [nitroCharge, setNitroCharge] = useState<number>(0);
  const [isNitroActive, setIsNitroActive] = useState<boolean>(false);
  const [isNitroRequested, setIsNitroRequested] = useState<boolean>(false);

  // Apply settings to soundManager upon app mount
  useEffect(() => {
    soundManager.setSoundEnabled(settings.soundEnabled);
    soundManager.setMusicEnabled(settings.musicEnabled);
    
    // Auto-save settings when edited
    localStorage.setItem('endless_car_racer_settings', JSON.stringify(settings));
  }, [settings]);

  // Sync Coins and Unlocked Cars to Local Storage when they change
  useEffect(() => {
    localStorage.setItem('endless_car_racer_coins', coins.toString());
  }, [coins]);

  useEffect(() => {
    localStorage.setItem('endless_car_racer_unlocked_cars', JSON.stringify(unlockedCarIds));
  }, [unlockedCarIds]);

  // Handle game start
  const handleStartGame = () => {
    setCurrentScore(0);
    setCurrentSpeed(0);
    setDistanceTravelled(0);
    setIsNewRecord(false);
    
    setCoinsCollectedThisRound(0);
    setNitroCharge(0);
    setIsNitroActive(false);
    setIsNitroRequested(false);
    
    setGameState('playing');
    
    // Play sound and resume synth music
    soundManager.startEngine();
    soundManager.startMusic();
  };

  // Toggle pause
  const handlePause = () => {
    if (gameState === 'playing') {
      setGameState('paused');
      soundManager.stopEngine();
    } else if (gameState === 'paused') {
      setGameState('playing');
      soundManager.startEngine();
    }
  };

  // Quick restart from HUD or gameover
  const handleRestart = () => {
    setCurrentScore(0);
    setCurrentSpeed(0);
    setDistanceTravelled(0);
    setIsNewRecord(false);
    
    setCoinsCollectedThisRound(0);
    setNitroCharge(0);
    setIsNitroActive(false);
    setIsNitroRequested(false);
    
    setGameState('playing');
    
    soundManager.startEngine();
    soundManager.startMusic();
  };

  // Handle Crash/Collision
  const handleCrash = (finalScore: number, finalDistance: number, coinsCollected: number) => {
    setLastScore(finalScore);
    localStorage.setItem('endless_car_racer_lastscore', finalScore.toString());
    setDistanceTravelled(finalDistance);
    
    let isRecord = false;
    if (finalScore > highScore) {
      isRecord = true;
      setHighScore(finalScore);
      localStorage.setItem('endless_car_racer_highscore', finalScore.toString());
      setIsNewRecord(true);
    }

    // Award coins based on user criteria:
    // < 100 points = 20 Coins
    // 100–300 = 50 Coins
    // 300–600 = 100 Coins
    // > 600 = 200 Coins
    let bonusCoins = 20;
    if (finalScore >= 100 && finalScore < 300) {
      bonusCoins = 50;
    } else if (finalScore >= 300 && finalScore <= 600) {
      bonusCoins = 100;
    } else if (finalScore > 600) {
      bonusCoins = 200;
    }
    
    const earned = coinsCollected + bonusCoins;
    setCoinsEarnedLastRound(earned);
    setCoins(prev => prev + earned);
    
    setGameState('gameover');
    soundManager.stopEngine();
  };

  // Update real-time HUD values from loop
  const handleUpdateScore = (score: number, speed: number) => {
    setCurrentScore(score);
    setCurrentSpeed(speed);
  };

  // Update real-time HUD including Coins and Nitro charge
  const handleUpdateHUD = (score: number, speed: number, coinsCol: number, nitroChargeVal: number, nitroActiveVal: boolean) => {
    setCurrentScore(score);
    setCurrentSpeed(speed);
    setCoinsCollectedThisRound(coinsCol);
    setNitroCharge(nitroChargeVal);
    setIsNitroActive(nitroActiveVal);
  };

  // Selection callbacks
  const handleSelectCar = (id: string) => {
    setSelectedCarId(id);
    localStorage.setItem('endless_car_racer_car', id);
  };

  const handleSelectRoad = (id: string) => {
    setSelectedRoadId(id);
    localStorage.setItem('endless_car_racer_road', id);
  };

  const handleToggleSoundHUD = () => {
    const updated = { ...settings, soundEnabled: !settings.soundEnabled };
    setSettings(updated);
  };

  // Handle purchase logic
  const handleBuyCar = (id: string, price: number) => {
    if (coins >= price && !unlockedCarIds.includes(id)) {
      setCoins(prev => prev - price);
      setUnlockedCarIds(prev => [...prev, id]);
      soundManager.playScoreBeep(); // Celebratory chime sound!
    }
  };

  return (
    <div id="app-root-container" className="w-screen h-screen flex bg-slate-950 overflow-hidden font-sans select-none antialiased">
      
      {/* LEFT SIDE PANEL - Cinematic brand decor on desktop screens */}
      <aside className="hidden lg:flex flex-col justify-between p-8 w-80 shrink-0 border-r border-white/10 bg-black/60 relative overflow-hidden text-white select-none">
        
        {/* Subtle geometric neon background */}
        <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-rose-500/10 to-transparent" />
        
        <div>
          <div className="flex items-center gap-2 mb-6">
            <Smartphone className="w-5 h-5 text-rose-500 animate-pulse" />
            <span className="text-xs uppercase tracking-widest font-black text-rose-500">منصة ألعاب الهواتف</span>
          </div>

          <h2 className="text-2xl font-black tracking-tight leading-none">Endless Car</h2>
          <h3 className="text-3xl font-black text-rose-500 leading-none mb-4">Racer 3D</h3>
          <p className="text-xs text-gray-400 leading-relaxed mb-6">
            محاكاة سباقات طريق سريعة متكاملة تم تطويرها خصيصاً للجوال لتعمل بسرعة 60 إطار في الثانية وبأداء فائق السلاسة.
          </p>

          <div className="flex flex-col gap-3.5 bg-white/5 border border-white/10 rounded-2xl p-4">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              <span className="text-xs font-bold text-gray-300">أعلى النقاط</span>
            </div>
            <div className="text-3xl font-black font-mono text-amber-400 tracking-wider">
              {highScore.toLocaleString()}
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 text-[10px] text-gray-500 font-bold uppercase tracking-wide">
            <ShieldAlert className="w-3.5 h-3.5 text-cyan-400" />
            <span>نظام التحكم السلس باللمس</span>
          </div>
          <p className="text-[11px] text-gray-500 leading-normal">
            اسحب بإصبعك على شاشة الهاتف يميناً ويساراً للتوجيه الفوري والسلس وتجنب السيارات المعاكسة التي تزداد سرعتها تدريجياً.
          </p>
        </div>

      </aside>

      {/* PRIMARY GAME viewport frame */}
      <section className="flex-1 h-full flex items-center justify-center relative">
        
        {/* We constrain the play window to standard phone aspect ratios on desktop to guarantee true Mobile-First optimization styling */}
        <div className="w-full h-full max-w-md lg:max-w-lg lg:h-[92vh] lg:my-auto bg-black relative lg:rounded-3xl lg:overflow-hidden lg:shadow-[0_0_80px_rgba(239,68,68,0.2)] border border-transparent lg:border-white/10 flex flex-col">
          
          {/* THREE.JS 3D ENVIRONMENT CANVAS */}
          <GameCanvas
            selectedCarId={selectedCarId}
            selectedRoadId={selectedRoadId}
            gameState={gameState}
            settings={settings}
            onCrash={handleCrash}
            onUpdateScore={handleUpdateScore}
            isNitroRequested={isNitroRequested}
            onNitroStarted={() => setIsNitroRequested(false)}
            onUpdateHUD={handleUpdateHUD}
          />

          {/* OVERLAYS DEPENDING ON STATE */}
          
          {/* 1. Main Menu State */}
          {gameState === 'menu' && (
            <MainMenu
              highScore={highScore}
              lastScore={lastScore}
              selectedCarId={selectedCarId}
              selectedRoadId={selectedRoadId}
              settings={settings}
              onStartGame={handleStartGame}
              onSelectCar={handleSelectCar}
              onSelectRoad={handleSelectRoad}
              onUpdateSettings={setSettings}
              coins={coins}
              unlockedCarIds={unlockedCarIds}
              onBuyCar={handleBuyCar}
            />
          )}

          {/* 2. Active Racing HUD */}
          {(gameState === 'playing' || gameState === 'paused') && (
            <GameHUD
              score={currentScore}
              speed={currentSpeed}
              coinsCollected={coinsCollectedThisRound}
              nitroCharge={nitroCharge}
              isNitroActive={isNitroActive}
              onTriggerNitro={() => {
                if (nitroCharge >= 100 && !isNitroActive) {
                  setIsNitroRequested(true);
                }
              }}
              onPause={handlePause}
              isPaused={gameState === 'paused'}
              onRestart={handleRestart}
              onGoHome={() => setGameState('menu')}
              soundEnabled={settings.soundEnabled}
              onToggleSound={handleToggleSoundHUD}
            />
          )}

          {/* 3. Collision Game Over State */}
          {gameState === 'gameover' && (
            <GameOver
              score={currentScore}
              distance={distanceTravelled}
              highScore={highScore}
              isNewRecord={isNewRecord}
              onRestart={handleRestart}
              onGoHome={() => setGameState('menu')}
              coinsEarned={coinsEarnedLastRound}
            />
          )}

        </div>

      </section>

      {/* RIGHT SIDE PANEL - Specs & stats for landscape layout desktops */}
      <aside className="hidden xl:flex flex-col justify-between p-8 w-80 shrink-0 border-l border-white/10 bg-black/60 relative overflow-hidden text-white select-none">
        
        <div className="absolute bottom-0 right-0 w-full h-1/2 bg-gradient-to-t from-cyan-500/5 to-transparent" />

        <div className="flex flex-col gap-5">
          <div className="flex items-center gap-2">
            <Monitor className="w-5 h-5 text-cyan-400" />
            <span className="text-xs uppercase tracking-widest font-black text-cyan-400">محرك رسومات الويب</span>
          </div>

          <div className="flex flex-col gap-2.5">
            <h4 className="text-sm font-bold text-gray-300">مواصفات اللعبة التقنية:</h4>
            <ul className="text-xs text-gray-400 flex flex-col gap-2">
              <li className="flex justify-between border-b border-white/5 pb-1">
                <span>المحرك</span>
                <span className="font-mono text-cyan-400 font-bold">Three.js R152</span>
              </li>
              <li className="flex justify-between border-b border-white/5 pb-1">
                <span>الصوت</span>
                <span className="font-mono text-rose-500 font-bold">Web Audio Synth</span>
              </li>
              <li className="flex justify-between border-b border-white/5 pb-1">
                <span>معدل الفريمات</span>
                <span className="font-mono text-emerald-400 font-bold">60 FPS Locked</span>
              </li>
              <li className="flex justify-between">
                <span>نظام التخزين</span>
                <span className="font-mono text-amber-500 font-bold">HTML5 LocalStorage</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="text-center bg-cyan-950/20 border border-cyan-500/10 rounded-2xl p-4 flex flex-col items-center">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping mb-2" />
          <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-widest">جاهز للتصدير كـ APK</span>
          <p className="text-[10px] text-gray-500 mt-1 leading-normal">
            الكود مهيأ بالكامل ليتم تصديره وتغليفه باستخدام Cordova أو Capacitor إلى ملف تثبيت أندرويد نهائي ومثالي.
          </p>
        </div>

      </aside>

    </div>
  );
}

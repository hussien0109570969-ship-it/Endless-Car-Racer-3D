/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class SoundManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private engineMod: OscillatorNode | null = null; // Frequency modulation for piston effect
  
  private musicEnabled: boolean = true;
  private soundEnabled: boolean = true;
  private isMusicPlaying: boolean = false;
  
  // Music sequencer variables
  private seqInterval: number | null = null;
  private currentBeat: number = 0;
  private nextNoteTime: number = 0.0;
  private tempo: number = 130; // BPM
  private beats: number[] = [0, 1, 2, 3, 4, 5, 6, 7]; // 8-step sequencer
  
  constructor() {
    // Audio Context is initialized lazily upon first user interaction
  }

  private init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.connect(this.ctx.destination);
      this.masterGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
      
      // Start engine oscillator setup
      this.setupEngine();
    } catch (e) {
      console.warn('Web Audio API not supported in this browser:', e);
    }
  }

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
    if (enabled) {
      this.resumeContext();
    }
    this.updateGains();
  }

  public setMusicEnabled(enabled: boolean) {
    this.musicEnabled = enabled;
    if (enabled) {
      this.resumeContext();
      this.startMusic();
    } else {
      this.stopMusic();
    }
  }

  private resumeContext() {
    this.init();
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private updateGains() {
    if (!this.masterGain || !this.ctx) return;
    const volume = this.soundEnabled ? 0.8 : 0.0;
    this.masterGain.gain.setTargetAtTime(volume, this.ctx.currentTime, 0.1);
  }

  // --- ENGINE SYNTHESIS ---
  private setupEngine() {
    if (!this.ctx || !this.masterGain) return;
    
    try {
      // Base engine hum
      this.engineOsc = this.ctx.createOscillator();
      this.engineGain = this.ctx.createGain();
      
      // Low-pass filter to sound deep
      const lpFilter = this.ctx.createBiquadFilter();
      lpFilter.type = 'lowpass';
      lpFilter.frequency.setValueAtTime(250, this.ctx.currentTime);
      lpFilter.Q.setValueAtTime(1.5, this.ctx.currentTime);
      
      this.engineOsc.type = 'sawtooth';
      this.engineOsc.frequency.setValueAtTime(35, this.ctx.currentTime); // Low idle hum
      
      // Modulator for piston rumble
      this.engineMod = this.ctx.createOscillator();
      const modGain = this.ctx.createGain();
      this.engineMod.frequency.setValueAtTime(12, this.ctx.currentTime); // 12Hz rumble
      modGain.gain.setValueAtTime(6, this.ctx.currentTime); // 6Hz pitch deviation
      
      this.engineMod.connect(modGain);
      modGain.connect(this.engineOsc.frequency);
      
      this.engineOsc.connect(lpFilter);
      lpFilter.connect(this.engineGain);
      this.engineGain.connect(this.masterGain);
      
      this.engineGain.gain.setValueAtTime(0, this.ctx.currentTime); // Starts silent
      
      this.engineOsc.start();
      this.engineMod.start();
    } catch (err) {
      console.error('Engine audio setup failed', err);
    }
  }

  public startEngine() {
    this.resumeContext();
    if (!this.engineGain || !this.ctx) return;
    if (!this.soundEnabled) return;
    
    this.engineGain.gain.setTargetAtTime(0.18, this.ctx.currentTime, 0.2);
  }

  public setEngineSpeed(speedRatio: number) {
    if (!this.ctx || !this.engineOsc || !this.engineGain) return;
    
    // Clamp speed ratio between 0 and 1
    const r = Math.max(0, Math.min(1, speedRatio));
    const baseFreq = 35 + r * 140; // Idle 35Hz to max speed 175Hz
    const rumbleFreq = 10 + r * 25; // Modulation speed increases with RPM
    
    this.engineOsc.frequency.setTargetAtTime(baseFreq, this.ctx.currentTime, 0.1);
    if (this.engineMod) {
      this.engineMod.frequency.setTargetAtTime(rumbleFreq, this.ctx.currentTime, 0.1);
    }
    
    // Engine gets slightly louder and buzzy at high speeds
    const engineVol = this.soundEnabled ? 0.12 + r * 0.12 : 0;
    this.engineGain.gain.setTargetAtTime(engineVol, this.ctx.currentTime, 0.15);
  }

  public stopEngine() {
    if (!this.engineGain || !this.ctx) return;
    this.engineGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.3);
  }

  // --- SOUND EFFECTS ---

  /**
   * High pitch sweeping tire squeal for brake and sudden turn steering
   */
  public playBrakeSqueal() {
    this.resumeContext();
    if (!this.soundEnabled || !this.ctx || !this.masterGain) return;
    
    try {
      const time = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1400, time);
      osc.frequency.exponentialRampToValueAtTime(700, time + 0.35);
      
      // Filter to add raspiness to squealing brakes
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1000, time);
      filter.Q.setValueAtTime(1.0, time);
      
      gain.gain.setValueAtTime(0.08, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.35);
      
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);
      
      osc.start(time);
      osc.stop(time + 0.36);
    } catch (e) {}
  }

  /**
   * Sound when moving lane left/right (whoosh)
   */
  public playLaneChange() {
    this.resumeContext();
    if (!this.soundEnabled || !this.ctx || !this.masterGain) return;
    
    try {
      const time = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(180, time);
      osc.frequency.exponentialRampToValueAtTime(320, time + 0.15);
      
      gain.gain.setValueAtTime(0.12, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.18);
      
      osc.connect(gain);
      gain.connect(this.masterGain);
      
      osc.start(time);
      osc.stop(time + 0.2);
    } catch (e) {}
  }

  /**
   * Explosion / Crash Sound Effect
   */
  public playCrash() {
    this.resumeContext();
    if (!this.soundEnabled || !this.ctx || !this.masterGain) return;
    
    try {
      const time = this.ctx.currentTime;
      const duration = 1.8;
      
      // 1. Create White Noise buffer
      const bufferSize = this.ctx.sampleRate * duration;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      
      const noiseNode = this.ctx.createBufferSource();
      noiseNode.buffer = buffer;
      
      // High-cut filter on noise for explosive rumble
      const lowpass = this.ctx.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.setValueAtTime(350, time);
      lowpass.frequency.exponentialRampToValueAtTime(50, time + duration);
      
      const noiseGain = this.ctx.createGain();
      noiseGain.gain.setValueAtTime(0.5, time);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, time + duration);
      
      noiseNode.connect(lowpass);
      lowpass.connect(noiseGain);
      noiseGain.connect(this.masterGain);
      
      // 2. Heavy Sub-Bass Boom
      const subOsc = this.ctx.createOscillator();
      const subGain = this.ctx.createGain();
      subOsc.type = 'sawtooth';
      subOsc.frequency.setValueAtTime(120, time);
      subOsc.frequency.linearRampToValueAtTime(30, time + 0.8);
      
      subGain.gain.setValueAtTime(0.4, time);
      subGain.gain.exponentialRampToValueAtTime(0.001, time + 0.8);
      
      subOsc.connect(subGain);
      subGain.connect(this.masterGain);
      
      noiseNode.start(time);
      subOsc.start(time);
      
      noiseNode.stop(time + duration);
      subOsc.stop(time + 0.9);
    } catch (e) {}
  }

  /**
   * Sound when scoring or collecting score milestones (double chime)
   */
  public playScoreBeep() {
    this.resumeContext();
    if (!this.soundEnabled || !this.ctx || !this.masterGain) return;
    
    try {
      const time = this.ctx.currentTime;
      
      const playChime = (freq: number, delay: number) => {
        if (!this.ctx || !this.masterGain) return;
        const o = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, time + delay);
        
        g.gain.setValueAtTime(0.15, time + delay);
        g.gain.exponentialRampToValueAtTime(0.001, time + delay + 0.15);
        
        o.connect(g);
        g.connect(this.masterGain);
        o.start(time + delay);
        o.stop(time + delay + 0.2);
      };
      
      playChime(784, 0); // G5 note
      playChime(1046, 0.08); // C6 note
    } catch (e) {}
  }

  /**
   * Classic retro high-pitched ascending dual-tone coin collection sound
   */
  public playCoinCollect() {
    this.resumeContext();
    if (!this.soundEnabled || !this.ctx || !this.masterGain) return;
    
    try {
      const time = this.ctx.currentTime;
      
      const playTone = (freq: number, startDelay: number, dur: number) => {
        if (!this.ctx || !this.masterGain) return;
        const o = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, time + startDelay);
        
        g.gain.setValueAtTime(0.12, time + startDelay);
        g.gain.exponentialRampToValueAtTime(0.001, time + startDelay + dur);
        
        o.connect(g);
        g.connect(this.masterGain);
        o.start(time + startDelay);
        o.stop(time + startDelay + dur + 0.05);
      };
      
      playTone(987.77, 0, 0.08); // B5 note
      playTone(1318.51, 0.05, 0.15); // E6 note
    } catch (e) {}
  }

  /**
   * Heavy sci-fi engine ascending pitch sweep for Nitro Boost activation
   */
  public playNitroBoost() {
    this.resumeContext();
    if (!this.soundEnabled || !this.ctx || !this.masterGain) return;
    
    try {
      const time = this.ctx.currentTime;
      const duration = 0.5;
      
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(220, time);
      o.frequency.exponentialRampToValueAtTime(780, time + duration);
      
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(350, time);
      filter.frequency.exponentialRampToValueAtTime(3200, time + duration);
      
      g.gain.setValueAtTime(0.2, time);
      g.gain.exponentialRampToValueAtTime(0.001, time + duration);
      
      o.connect(filter);
      filter.connect(g);
      g.connect(this.masterGain);
      
      o.start(time);
      o.stop(time + duration + 0.05);
    } catch (e) {}
  }

  // --- SYNTHWAVE SEQUENCED BACKGROUND MUSIC ---
  // A dynamic procedural synthwave track consisting of:
  // - Step 1: Bassline bouncing on minor scale chord progression
  // - Step 2: Synth Chords
  // - Step 3: Minimal arcade kick and snare drum simulation
  
  public startMusic() {
    this.resumeContext();
    if (this.isMusicPlaying) return;
    if (!this.musicEnabled) return;
    
    this.isMusicPlaying = true;
    this.nextNoteTime = this.ctx ? this.ctx.currentTime : 0;
    this.currentBeat = 0;
    
    // Launch background timing loop
    this.seqInterval = window.setInterval(() => {
      this.scheduler();
    }, 50) as unknown as number;
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.seqInterval !== null) {
      clearInterval(this.seqInterval);
      this.seqInterval = null;
    }
  }

  private scheduler() {
    if (!this.ctx) return;
    // Schedule notes slightly ahead of the current playback time
    while (this.nextNoteTime < this.ctx.currentTime + 0.15) {
      this.schedulePlayStep(this.currentBeat, this.nextNoteTime);
      this.advanceStep();
    }
  }

  private advanceStep() {
    const secondsPerBeat = 60.0 / this.tempo / 2; // 8th notes at current BPM
    this.nextNoteTime += secondsPerBeat;
    this.currentBeat = (this.currentBeat + 1) % 16; // 16-step grid
  }

  private schedulePlayStep(step: number, time: number) {
    if (!this.ctx || !this.masterGain || !this.musicEnabled) return;

    // Chord progressions in A minor: Am, F, C, G (spanning 4 bars)
    // 16 steps = 2 bars (8 steps per bar)
    const bar = Math.floor(step / 8);
    const stepInBar = step % 8;
    
    // Decide Root Note based on simple loop (Am -> F -> C -> G)
    // Every 32 steps (4 bars), change root note
    const chordIdx = Math.floor(this.currentBeat / 4) % 4;
    const roots = [110, 87.3, 130.8, 98.0]; // A2, F2, C3, G2
    const root = roots[chordIdx];
    
    // 1. DYNAMIC BASS SYNTH (sawtooth) on 8th notes
    // classic bouncing bass rhythm: stepInBar % 2 === 0 is main, else high oct/sub
    if (this.soundEnabled && this.musicEnabled) {
      try {
        const bassOsc = this.ctx.createOscillator();
        const bassGain = this.ctx.createGain();
        
        bassOsc.type = 'sawtooth';
        
        let freq = root;
        if (stepInBar % 2 !== 0) {
          freq = root * 2.0; // Bouncing octave up
        }
        
        bassOsc.frequency.setValueAtTime(freq, time);
        
        // Dark retro lowpass filter
        const bassFilter = this.ctx.createBiquadFilter();
        bassFilter.type = 'lowpass';
        bassFilter.frequency.setValueAtTime(140, time);
        
        bassGain.gain.setValueAtTime(0.08, time);
        bassGain.gain.exponentialRampToValueAtTime(0.001, time + 0.18);
        
        bassOsc.connect(bassFilter);
        bassFilter.connect(bassGain);
        bassGain.connect(this.masterGain);
        
        bassOsc.start(time);
        bassOsc.stop(time + 0.2);
      } catch (e) {}
    }

    // 2. SYNTH MELODY (triangle/square) - Retro Arcade Arpeggio
    // Plays notes from the pentatonic scale of the current chord
    const playMelody = step % 2 === 0; // Alternating steps
    if (playMelody && this.soundEnabled && this.musicEnabled) {
      try {
        // Pentatonic indices
        const scaleOffsets = [1, 1.2, 1.5, 1.6, 1.8, 2.0];
        const noteFactor = scaleOffsets[(step + chordIdx * 2) % scaleOffsets.length];
        const melodyFreq = root * 4 * noteFactor; // Move to 4th octave
        
        const melOsc = this.ctx.createOscillator();
        const melGain = this.ctx.createGain();
        
        // Triangle has a pleasant retro video game timbre
        melOsc.type = 'triangle';
        melOsc.frequency.setValueAtTime(melodyFreq, time);
        
        melGain.gain.setValueAtTime(0.04, time);
        melGain.gain.exponentialRampToValueAtTime(0.001, time + 0.22);
        
        melOsc.connect(melGain);
        melGain.connect(this.masterGain);
        
        melOsc.start(time);
        melOsc.stop(time + 0.25);
      } catch (e) {}
    }

    // 3. SYNTHESIZED SYNTHWAVE DRUMS
    // Beat sequence: 
    // Kick (synthesized bass drop) on steps 0, 4, 8, 12
    // Snare (noisy static explosion) on steps 4, 12
    const isKick = step % 4 === 0;
    const isSnare = step % 8 === 4;
    
    if (isKick && this.soundEnabled && this.musicEnabled) {
      try {
        // Simple kick simulation: sine wave frequency sweep (150Hz -> 40Hz)
        const kickOsc = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kickOsc.type = 'sine';
        kickOsc.frequency.setValueAtTime(150, time);
        kickOsc.frequency.exponentialRampToValueAtTime(45, time + 0.08);
        
        kickGain.gain.setValueAtTime(0.25, time);
        kickGain.gain.exponentialRampToValueAtTime(0.001, time + 0.12);
        
        kickOsc.connect(kickGain);
        kickGain.connect(this.masterGain);
        kickOsc.start(time);
        kickOsc.stop(time + 0.14);
      } catch (e) {}
    }
    
    if (isSnare && this.soundEnabled && this.musicEnabled) {
      try {
        // Simple snare simulation: white noise bursts with bandpass filter at 1000Hz
        const bufferSize = this.ctx.sampleRate * 0.15; // 150ms
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }
        
        const noiseNode = this.ctx.createBufferSource();
        noiseNode.buffer = buffer;
        
        const bpFilter = this.ctx.createBiquadFilter();
        bpFilter.type = 'bandpass';
        bpFilter.frequency.setValueAtTime(1000, time);
        bpFilter.Q.setValueAtTime(2.0, time);
        
        const snareGain = this.ctx.createGain();
        snareGain.gain.setValueAtTime(0.06, time);
        snareGain.gain.exponentialRampToValueAtTime(0.001, time + 0.15);
        
        noiseNode.connect(bpFilter);
        bpFilter.connect(snareGain);
        snareGain.connect(this.masterGain);
        
        noiseNode.start(time);
        noiseNode.stop(time + 0.16);
      } catch (e) {}
    }
  }
}

export const soundManager = new SoundManager();

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { CARS, ROADS, CarConfig, RoadConfig, GameSettings } from '../types';
import { soundManager } from '../soundManager';

interface GameCanvasProps {
  selectedCarId: string;
  selectedRoadId: string;
  gameState: 'menu' | 'playing' | 'gameover' | 'paused';
  settings: GameSettings;
  onCrash: (score: number, distance: number, coinsCollected: number) => void;
  onUpdateScore: (score: number, speed: number) => void;
  isNitroRequested?: boolean;
  onNitroStarted?: () => void;
  onUpdateHUD?: (score: number, speed: number, coinsCollected: number, nitroCharge: number, isNitroActive: boolean) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  selectedCarId,
  selectedRoadId,
  gameState,
  settings,
  onCrash,
  onUpdateScore,
  isNitroRequested = false,
  onNitroStarted,
  onUpdateHUD
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // References for game state inside the loop (to avoid closure issues)
  const stateRef = useRef({
    gameState,
    selectedCarId,
    selectedRoadId,
    settings,
    playerX: 0.0,
    targetPlayerX: 0.0,
    speed: 0.0,
    maxSpeed: 100, // MPH representation
    distance: 0.0,
    score: 0,
    speedFactor: 0.0, // Moving speed
    roadOffset: 0.0,
    isWrecked: false,
    keys: { left: false, right: false },
    shouldReset: false,
    
    // Nitro & Coins mechanics
    coinsCollected: 0,
    nitroCharge: 0.0,
    isNitroActive: false,
    nitroTimer: 0.0,
    gameTime: 0.0,
    isNitroRequested: false
  });

  // Keep stateRef in sync with React props
  useEffect(() => {
    const prevGameState = stateRef.current.gameState;

    stateRef.current.gameState = gameState;
    stateRef.current.selectedCarId = selectedCarId;
    stateRef.current.selectedRoadId = selectedRoadId;
    stateRef.current.settings = settings;
    stateRef.current.isNitroRequested = isNitroRequested;

    // Trigger full reset on starting or restarting
    if (gameState === 'playing' && (prevGameState === 'gameover' || prevGameState === 'menu')) {
      stateRef.current.shouldReset = true;
    }

    // Control sound manager engine pitch based on state
    if (gameState === 'playing' && !stateRef.current.isWrecked) {
      soundManager.startEngine();
      soundManager.setEngineSpeed(stateRef.current.speed / 180);
    } else {
      soundManager.stopEngine();
    }
  }, [gameState, selectedCarId, selectedRoadId, settings, isNitroRequested]);

  // Touch and Drag control handler
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let isDragging = false;
    let startTouchX = 0;
    let startCarX = 0;

    const handleTouchStart = (e: TouchEvent) => {
      if (stateRef.current.gameState !== 'playing' || stateRef.current.isWrecked) return;
      isDragging = true;
      const touch = e.touches[0];
      startTouchX = touch.clientX;
      startCarX = stateRef.current.playerX;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDragging || stateRef.current.gameState !== 'playing' || stateRef.current.isWrecked) return;
      const touch = e.touches[0];
      const deltaX = touch.clientX - startTouchX;
      
      // Screen width scaling
      const width = canvas.clientWidth || 1;
      // Sensitivity factor
      const sensitivity = stateRef.current.settings.sensitivity * 8.5;
      
      // Calculate new target position
      let targetX = startCarX + (deltaX / width) * sensitivity;
      // Clamp to road boundaries
      targetX = Math.max(-3.2, Math.min(3.2, targetX));
      stateRef.current.targetPlayerX = targetX;
    };

    const handleTouchEnd = () => {
      isDragging = false;
    };

    // Mouse equivalent for desktop testing
    const handleMouseDown = (e: MouseEvent) => {
      if (stateRef.current.gameState !== 'playing' || stateRef.current.isWrecked) return;
      isDragging = true;
      startTouchX = e.clientX;
      startCarX = stateRef.current.playerX;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || stateRef.current.gameState !== 'playing' || stateRef.current.isWrecked) return;
      const deltaX = e.clientX - startTouchX;
      const width = canvas.clientWidth || 1;
      const sensitivity = stateRef.current.settings.sensitivity * 8.5;
      
      let targetX = startCarX + (deltaX / width) * sensitivity;
      targetX = Math.max(-3.2, Math.min(3.2, targetX));
      stateRef.current.targetPlayerX = targetX;
    };

    const handleMouseUp = () => {
      isDragging = false;
    };

    // Keyboard support for desktop
    const handleKeyDown = (e: KeyboardEvent) => {
      if (stateRef.current.gameState !== 'playing' || stateRef.current.isWrecked) return;
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        stateRef.current.keys.left = true;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        stateRef.current.keys.right = true;
      }
      if (e.key === ' ' || e.key === 'Spacebar' || e.key === 'n' || e.key === 'N') {
        if (stateRef.current.nitroCharge >= 100 && !stateRef.current.isNitroActive) {
          stateRef.current.isNitroRequested = true;
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        stateRef.current.keys.left = false;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        stateRef.current.keys.right = false;
      }
    };

    canvas.addEventListener('touchstart', handleTouchStart, { passive: true });
    canvas.addEventListener('touchmove', handleTouchMove, { passive: true });
    canvas.addEventListener('touchend', handleTouchEnd);
    canvas.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleTouchEnd);
      canvas.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Main 3D Simulation Loop inside useEffect
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    // Create Renderer
    const width = container.clientWidth;
    const height = container.clientHeight;
    
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: settings.graphicsQuality !== 'low',
      alpha: false,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = settings.graphicsQuality === 'high';
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Create Scene
    const scene = new THREE.Scene();
    
    // Create Camera (Behind & slightly above the player car)
    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 3.8, 6.5);
    camera.lookAt(0, 1.2, -6);

    // Dynamic sky, fog, and light properties based on selected road/theme
    const currentRoad = ROADS.find(r => r.id === selectedRoadId) || ROADS[0];
    
    scene.background = new THREE.Color(currentRoad.skyColor);
    scene.fog = new THREE.FogExp2(currentRoad.fogColor, currentRoad.fogDensity);

    // Primary ambient light
    const ambientLight = new THREE.AmbientLight(currentRoad.ambientLightColor, 0.55);
    scene.add(ambientLight);

    // Directional Sunlight (casting shadows)
    const sunLight = new THREE.DirectionalLight(currentRoad.sunColor, 1.2);
    sunLight.position.set(20, 45, -15);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 150;
    const d = 25;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    scene.add(sunLight);

    // Secondary subtle fill light
    const fillLight = new THREE.DirectionalLight('#89b4e5', 0.3);
    fillLight.position.set(-20, 20, 20);
    scene.add(fillLight);

    // Material definitions for reuse
    const roadMaterial = new THREE.MeshStandardMaterial({
      color: '#1a1d24',
      roughness: 0.82,
      metalness: 0.1
    });

    const shoulderMaterial = new THREE.MeshStandardMaterial({
      color: currentRoad.groundColor,
      roughness: 0.9,
      metalness: 0.0
    });

    const laneLineMaterial = new THREE.MeshBasicMaterial({
      color: currentRoad.laneColor
    });

    // --- PROCEDURAL 3D CAR BUILDER ---
    const buildCarMesh = (car: CarConfig): THREE.Group => {
      const carGroup = new THREE.Group();

      // Main materials
      const bodyMat = new THREE.MeshStandardMaterial({
        color: car.color,
        roughness: 0.18,
        metalness: car.type === 'supercar' ? 0.9 : 0.4
      });

      const stripeMat = new THREE.MeshStandardMaterial({
        color: car.secondaryColor,
        roughness: 0.2,
        metalness: 0.3
      });

      const windowMat = new THREE.MeshStandardMaterial({
        color: '#080c10',
        roughness: 0.05,
        metalness: 0.95
      });

      const wheelMat = new THREE.MeshStandardMaterial({
        color: '#111111',
        roughness: 0.8
      });

      const rimMat = new THREE.MeshStandardMaterial({
        color: car.rimColor,
        roughness: 0.1,
        metalness: 0.95
      });

      const lightGlowMat = new THREE.MeshBasicMaterial({
        color: '#ffffea'
      });

      const tailGlowMat = new THREE.MeshBasicMaterial({
        color: '#ff1111'
      });

      // Assemble car body
      if (car.isF1) {
        // F1 Race Car Model
        const nose = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.2, 1.8), bodyMat);
        nose.position.set(0, 0.1, -0.6);
        carGroup.add(nose);

        const cockpit = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.3, 1.2), bodyMat);
        cockpit.position.set(0, 0.2, 0.4);
        carGroup.add(cockpit);

        // Side pods
        const podL = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.3, 1.0), stripeMat);
        podL.position.set(-0.5, 0.15, 0.4);
        const podR = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.3, 1.0), stripeMat);
        podR.position.set(0.5, 0.15, 0.4);
        carGroup.add(podL, podR);

        // Wings
        const frontWing = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.1, 0.3), stripeMat);
        frontWing.position.set(0, 0.06, -1.5);
        carGroup.add(frontWing);

        const rearWingMain = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.15, 0.4), stripeMat);
        rearWingMain.position.set(0, 0.8, 1.1);
        const wingPillarL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.8, 0.1), bodyMat);
        wingPillarL.position.set(-0.5, 0.4, 1.0);
        const wingPillarR = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.8, 0.1), bodyMat);
        wingPillarR.position.set(0.5, 0.4, 1.0);
        carGroup.add(rearWingMain, wingPillarL, wingPillarR);
      } else if (car.isAngular) {
        // CyberTruck Style
        const shellGeom = new THREE.BufferGeometry();
        // Custom angular points for cyberpunk truck
        const vertices = new Float32Array([
          // Front nose
          -0.75, 0.1, -1.6,   0.75, 0.1, -1.6,   0.75, 0.4, -1.0,
          -0.75, 0.1, -1.6,   0.75, 0.4, -1.0,  -0.75, 0.4, -1.0,
          // Windshield angle to peak
          -0.75, 0.4, -1.0,   0.75, 0.4, -1.0,   0.72, 0.9,  0.1,
          -0.75, 0.4, -1.0,   0.72, 0.9,  0.1,  -0.72, 0.9,  0.1,
          // Slanted rear trunk
          -0.72, 0.9,  0.1,   0.72, 0.9,  0.1,   0.75, 0.5,  1.5,
          -0.72, 0.9,  0.1,   0.75, 0.5,  1.5,  -0.75, 0.5,  1.5,
          // Flat Bottom / sides (simplified as box elements for robustness)
        ]);
        shellGeom.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
        shellGeom.computeVertexNormals();
        
        const angularShell = new THREE.Mesh(shellGeom, bodyMat);
        carGroup.add(angularShell);

        // Backup visual block to prevent empty hollows
        const bottomBox = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.4, 3.1), bodyMat);
        bottomBox.position.set(0, 0.25, 0);
        carGroup.add(bottomBox);

        // LED Light bar (cyber)
        const lightBar = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.05, 0.1), lightGlowMat);
        lightBar.position.set(0, 0.35, -1.58);
        carGroup.add(lightBar);
      } else {
        // Standard high-detail procedural car
        // Bottom chassis
        const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.35, 3.3), bodyMat);
        chassis.position.set(0, 0.25, 0);
        chassis.castShadow = true;
        chassis.receiveShadow = true;
        carGroup.add(chassis);

        // Top Cabin
        const cabinWidth = car.hasOpenTop ? 1.0 : 1.3;
        const cabinHeight = car.hasOpenTop ? 0.2 : 0.45;
        const cabinLength = car.hasOpenTop ? 1.0 : 1.6;
        
        const cabin = new THREE.Mesh(new THREE.BoxGeometry(cabinWidth, cabinHeight, cabinLength), car.hasOpenTop ? stripeMat : windowMat);
        cabin.position.set(0, 0.55 + (car.hasOpenTop ? -0.1 : 0), 0.1);
        cabin.castShadow = true;
        carGroup.add(cabin);

        if (car.hasOpenTop) {
          // Inner seat cutouts representation (dark headrests)
          const seatL = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.3, 0.2), windowMat);
          seatL.position.set(-0.25, 0.55, 0.15);
          const seatR = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.3, 0.2), windowMat);
          seatR.position.set(0.25, 0.55, 0.15);
          carGroup.add(seatL, seatR);
        }

        // Colored accent racing stripes
        if (car.secondaryColor !== car.color) {
          const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.02, 3.32), stripeMat);
          stripe.position.set(0, 0.43, 0);
          carGroup.add(stripe);
        }

        // Spoiler
        if (car.hasSpoiler) {
          const spoilerWing = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.08, 0.4), bodyMat);
          spoilerWing.position.set(0, 0.72, 1.4);
          
          const pillarL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.3, 0.08), stripeMat);
          pillarL.position.set(-0.6, 0.55, 1.4);
          const pillarR = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.3, 0.08), stripeMat);
          pillarR.position.set(0.6, 0.55, 1.4);
          
          carGroup.add(spoilerWing, pillarL, pillarR);
        }

        // Supercharger scoop on the hood for muscle cars
        if (car.hasSupercharger) {
          const supercharger = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.2, 0.6), stripeMat);
          supercharger.position.set(0, 0.5, -0.8);
          
          const intake = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.1, 0.05), windowMat);
          intake.position.set(0, 0.52, -1.1);
          
          carGroup.add(supercharger, intake);
        }

        // Headlights
        const headL = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.12, 0.1), lightGlowMat);
        headL.position.set(-0.55, 0.3, -1.62);
        const headR = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.12, 0.1), lightGlowMat);
        headR.position.set(0.55, 0.3, -1.62);
        carGroup.add(headL, headR);

        // Taillights
        const tailL = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.08, 0.1), tailGlowMat);
        tailL.position.set(-0.5, 0.35, 1.62);
        const tailR = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.08, 0.1), tailGlowMat);
        tailR.position.set(0.5, 0.35, 1.62);
        carGroup.add(tailL, tailR);
      }

      // Wheels setup (Open-wheel for F1 vs standard hidden-wheel wells)
      const wheelGeom = new THREE.CylinderGeometry(0.38, 0.38, 0.32, 16);
      wheelGeom.rotateZ(Math.PI / 2);
      
      const rimGeom = new THREE.CylinderGeometry(0.22, 0.22, 0.34, 12);
      rimGeom.rotateZ(Math.PI / 2);

      const positions = [
        { x: -0.82, y: 0.22, z: -0.95 },  // Front Left
        { x: 0.82, y: 0.22, z: -0.95 },   // Front Right
        { x: -0.82, y: 0.22, z: 1.0 },    // Rear Left
        { x: 0.82, y: 0.22, z: 1.0 }      // Rear Right
      ];

      positions.forEach(pos => {
        const wheel = new THREE.Mesh(wheelGeom, wheelMat);
        const rim = new THREE.Mesh(rimGeom, rimMat);
        wheel.add(rim);
        
        wheel.position.set(pos.x, pos.y, pos.z);
        wheel.castShadow = true;
        carGroup.add(wheel);
      });

      // Neon Underglow setup
      if (car.glowingNeon) {
        const neonColor = new THREE.Color(car.glowingNeon);
        const neonLight = new THREE.PointLight(neonColor, 1.8, 3.5);
        neonLight.position.set(0, 0.02, 0);
        carGroup.add(neonLight);

        // Visual underglow flat halo
        const haloGeom = new THREE.PlaneGeometry(1.6, 2.8);
        haloGeom.rotateX(-Math.PI / 2);
        const haloMat = new THREE.MeshBasicMaterial({
          color: neonColor,
          transparent: true,
          opacity: 0.45,
          blending: THREE.AdditiveBlending,
          side: THREE.DoubleSide
        });
        const halo = new THREE.Mesh(haloGeom, haloMat);
        halo.position.set(0, 0.01, 0);
        carGroup.add(halo);
      }

      return carGroup;
    };

    // Instantiate Player Car
    const currentCar = CARS.find(c => c.id === selectedCarId) || CARS[0];
    const playerCarGroup = buildCarMesh(currentCar);
    playerCarGroup.position.set(0, 0, 0);
    scene.add(playerCarGroup);

    // Create Flame Mesh for Nitro exhaust
    const flameGroup = new THREE.Group();
    const flameGeo = new THREE.ConeGeometry(0.18, 1.2, 8);
    // Move geometry pivot so the cone expands backwards from the exhaust pipes
    flameGeo.translate(0, -0.6, 0);
    const flameMat = new THREE.MeshBasicMaterial({
      color: '#06b6d4', // cyan neon
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending
    });
    
    const leftFlame = new THREE.Mesh(flameGeo, flameMat);
    leftFlame.rotation.x = -Math.PI / 2;
    leftFlame.position.set(-0.4, 0.25, 1.6);
    
    const rightFlame = new THREE.Mesh(flameGeo, flameMat);
    rightFlame.rotation.x = -Math.PI / 2;
    rightFlame.position.set(0.4, 0.25, 1.6);
    
    flameGroup.add(leftFlame, rightFlame);
    flameGroup.visible = false;
    playerCarGroup.add(flameGroup);

    // Headlights spotlight cone if Night Road
    let headlightLeftSpot: THREE.SpotLight | null = null;
    let headlightRightSpot: THREE.SpotLight | null = null;
    if (currentRoad.decorations === 'night') {
      headlightLeftSpot = new THREE.SpotLight('#ffffd5', 8.0, 32, Math.PI / 6, 0.5, 0.5);
      headlightLeftSpot.position.set(-0.55, 0.3, -1.6);
      
      headlightRightSpot = new THREE.SpotLight('#ffffd5', 8.0, 32, Math.PI / 6, 0.5, 0.5);
      headlightRightSpot.position.set(0.55, 0.3, -1.6);
      
      const targetL = new THREE.Object3D();
      targetL.position.set(-0.55, 0.1, -12);
      const targetR = new THREE.Object3D();
      targetR.position.set(0.55, 0.1, -12);
      
      playerCarGroup.add(headlightLeftSpot, headlightRightSpot);
      playerCarGroup.add(targetL, targetR);
      
      headlightLeftSpot.target = targetL;
      headlightRightSpot.target = targetR;
    }

    // --- PROCEDURAL ROADWAY SEGMENTS & ENDLESS LOOPER ---
    const segmentLength = 40;
    const totalSegments = 4;
    const roadSegments: THREE.Group[] = [];

    // Roadway Lane Marks, Shoulders, and Ground Plane
    for (let i = 0; i < totalSegments; i++) {
      const segmentGroup = new THREE.Group();
      segmentGroup.position.z = -i * segmentLength;

      // Asphalt Road Deck
      const roadDeck = new THREE.Mesh(new THREE.PlaneGeometry(8.0, segmentLength), roadMaterial);
      roadDeck.rotation.x = -Math.PI / 2;
      roadDeck.receiveShadow = true;
      segmentGroup.add(roadDeck);

      // Left Shoulder (grass / sand / snow)
      const leftShoulder = new THREE.Mesh(new THREE.PlaneGeometry(45.0, segmentLength), shoulderMaterial);
      leftShoulder.rotation.x = -Math.PI / 2;
      leftShoulder.position.set(-26.5, -0.01, 0);
      leftShoulder.receiveShadow = true;
      segmentGroup.add(leftShoulder);

      // Right Shoulder
      const rightShoulder = new THREE.Mesh(new THREE.PlaneGeometry(45.0, segmentLength), shoulderMaterial);
      rightShoulder.rotation.x = -Math.PI / 2;
      rightShoulder.position.set(26.5, -0.01, 0);
      rightShoulder.receiveShadow = true;
      segmentGroup.add(rightShoulder);

      // Yellow left boundary line
      const lineLeft = new THREE.Mesh(new THREE.PlaneGeometry(0.12, segmentLength), laneLineMaterial);
      lineLeft.rotation.x = -Math.PI / 2;
      lineLeft.position.set(-3.8, 0.01, 0);
      segmentGroup.add(lineLeft);

      // Yellow right boundary line
      const lineRight = new THREE.Mesh(new THREE.PlaneGeometry(0.12, segmentLength), laneLineMaterial);
      lineRight.rotation.x = -Math.PI / 2;
      lineRight.position.set(3.8, 0.01, 0);
      segmentGroup.add(lineRight);

      // White Lane Dividers (Dotted)
      // Lanes are roughly at: Left (-2.5), Middle (0), Right (2.5)
      // 2 lane divider lines separating 3 lanes
      const divOffsets = [-1.3, 1.3];
      divOffsets.forEach(offsetX => {
        for (let j = 0; j < segmentLength; j += 6) {
          const dash = new THREE.Mesh(new THREE.PlaneGeometry(0.10, 2.5), laneLineMaterial);
          dash.rotation.x = -Math.PI / 2;
          dash.position.set(offsetX, 0.012, -segmentLength / 2 + j + 1.25);
          segmentGroup.add(dash);
        }
      });

      scene.add(segmentGroup);
      roadSegments.push(segmentGroup);
    }

    // --- SIDE OBJECTS & ROAD CONES POOLING ---
    // Generate beautiful roadside decorations based on selected theme
    // We pool decorations to keep rendering light!
    const sideObjectsPool: { mesh: THREE.Group; side: 'left' | 'right'; relZ: number }[] = [];

    const createPineTree = (): THREE.Group => {
      const g = new THREE.Group();
      // Trunk
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 1.8), new THREE.MeshStandardMaterial({ color: '#5a3d28' }));
      trunk.position.y = 0.9;
      g.add(trunk);
      // Leaves (layered cones)
      const leafColor = currentRoad.decorations === 'snow' ? '#ffffff' : '#1e4620';
      const leafMat = new THREE.MeshStandardMaterial({ color: leafColor, roughness: 0.9 });
      for (let i = 0; i < 3; i++) {
        const leaves = new THREE.Mesh(new THREE.ConeGeometry(1.2 - i * 0.3, 1.4, 8), leafMat);
        leaves.position.y = 1.7 + i * 0.9;
        leaves.castShadow = true;
        g.add(leaves);
      }
      return g;
    };

    const createLeafyTree = (): THREE.Group => {
      const g = new THREE.Group();
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.3, 2.2), new THREE.MeshStandardMaterial({ color: '#4a2c11' }));
      trunk.position.y = 1.1;
      g.add(trunk);
      const leaves = new THREE.Mesh(new THREE.SphereGeometry(1.5, 8, 8), new THREE.MeshStandardMaterial({ color: '#2c5e1a', roughness: 0.9 }));
      leaves.position.y = 2.6;
      leaves.castShadow = true;
      g.add(leaves);
      return g;
    };

    const createCactus = (): THREE.Group => {
      const g = new THREE.Group();
      const greenMat = new THREE.MeshStandardMaterial({ color: '#44703a', roughness: 0.9 });
      // Main trunk
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 2.2), greenMat);
      stem.position.y = 1.1;
      g.add(stem);
      // Left arm
      const armL1 = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.6), greenMat);
      armL1.rotation.z = Math.PI / 2;
      armL1.position.set(-0.4, 1.2, 0);
      const armL2 = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.8), greenMat);
      armL2.position.set(-0.7, 1.5, 0);
      g.add(armL1, armL2);
      // Right arm
      const armR1 = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.6), greenMat);
      armR1.rotation.z = -Math.PI / 2;
      armR1.position.set(0.4, 1.5, 0);
      const armR2 = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.8), greenMat);
      armR2.position.set(0.7, 1.8, 0);
      g.add(armR1, armR2);
      return g;
    };

    const createRock = (): THREE.Group => {
      const g = new THREE.Group();
      const matColor = currentRoad.decorations === 'snow' ? '#8ba2b8' : '#7a6a5d';
      const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(1.4 + Math.random() * 0.8), new THREE.MeshStandardMaterial({ color: matColor, roughness: 0.92 }));
      rock.position.y = 0.5;
      rock.castShadow = true;
      g.add(rock);
      return g;
    };

    const createSkyscraper = (): THREE.Group => {
      const g = new THREE.Group();
      const h = 14 + Math.random() * 20;
      const building = new THREE.Mesh(new THREE.BoxGeometry(6, h, 6), new THREE.MeshStandardMaterial({ color: '#2a313d', roughness: 0.4, metalness: 0.5 }));
      building.position.y = h / 2;
      building.castShadow = true;
      g.add(building);

      // Glow-in-the-dark window rows
      const winCount = 12;
      const winColor = Math.random() > 0.4 ? '#ffff99' : '#00ffff';
      const winMat = new THREE.MeshBasicMaterial({ color: winColor });
      for (let row = 3; row < h - 2; row += 3) {
        const windowRowL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.6, 4), winMat);
        windowRowL.position.set(-3.02, row - h/2, 0);
        const windowRowR = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.6, 4), winMat);
        windowRowR.position.set(3.02, row - h/2, 0);
        building.add(windowRowL, windowRowR);
      }
      return g;
    };

    const createStreetLamp = (): THREE.Group => {
      const g = new THREE.Group();
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 5), new THREE.MeshStandardMaterial({ color: '#42454d', metalness: 0.8 }));
      pole.position.y = 2.5;
      g.add(pole);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.15, 0.15), new THREE.MeshStandardMaterial({ color: '#42454d' }));
      arm.position.set(-0.7, 5, 0);
      g.add(arm);

      // Neon yellow glowing tip
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.2, 0.3), new THREE.MeshBasicMaterial({ color: '#ffffdd' }));
      lamp.position.set(-1.4, 4.9, 0);
      g.add(lamp);

      // Volumetric light cone representation
      const coneGeom = new THREE.ConeGeometry(2.5, 5, 16, 1, true);
      coneGeom.translate(0, -2.5, 0);
      const coneMat = new THREE.MeshBasicMaterial({
        color: '#ffffb3',
        transparent: true,
        opacity: 0.16,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        depthWrite: false
      });
      const lightCone = new THREE.Mesh(coneGeom, coneMat);
      lightCone.position.set(-1.4, 4.9, 0);
      g.add(lightCone);

      // Real spotlight casting on the road
      const spot = new THREE.SpotLight('#ffffb3', 15, 12, Math.PI / 4, 0.5, 1.0);
      spot.position.set(-1.4, 4.8, 0);
      spot.target.position.set(-1.4, 0, 0);
      g.add(spot, spot.target);

      return g;
    };

    // Decorate segments with side items
    const decorationType = currentRoad.decorations;
    
    // Distribute 16 roadside decorations along the loop
    for (let s = 0; s < 16; s++) {
      let sideMesh: THREE.Group;
      
      switch (decorationType) {
        case 'desert':
          sideMesh = Math.random() > 0.45 ? createCactus() : createRock();
          break;
        case 'snow':
          sideMesh = Math.random() > 0.4 ? createPineTree() : createRock();
          break;
        case 'night':
          sideMesh = Math.random() > 0.5 ? createStreetLamp() : createSkyscraper();
          break;
        case 'city':
          sideMesh = createSkyscraper();
          break;
        case 'mountain':
          sideMesh = Math.random() > 0.55 ? createRock() : createPineTree();
          break;
        case 'forest':
          sideMesh = Math.random() > 0.5 ? createLeafyTree() : createPineTree();
          break;
        default:
          sideMesh = createLeafyTree();
      }

      const side = s % 2 === 0 ? 'left' : 'right';
      // Distance from highway center line
      const offsetDistance = decorationType === 'city' || decorationType === 'night' ? 6.5 : 5.8;
      const x = side === 'left' ? -offsetDistance - Math.random() * 8 : offsetDistance + Math.random() * 8;
      const z = -s * 10 - Math.random() * 4;
      
      sideMesh.position.set(x, 0, z);
      scene.add(sideMesh);
      
      sideObjectsPool.push({
        mesh: sideMesh,
        side,
        relZ: z
      });
    }

    // --- OPPONENT/TRAFFIC CARS OBJECT POOLING ---
    // Pre-instantiate a pool of 6 traffic cars of diverse styles
    const trafficPool: { mesh: THREE.Group; lane: number; z: number; speed: number; colorHex: string }[] = [];
    const lanePositions = [-2.5, 0, 2.5]; // Left, center, right lanes

    for (let t = 0; t < 6; t++) {
      // Pick random car configs for traffic variation
      const randomConfig = CARS[Math.floor(Math.random() * CARS.length)];
      const trafficCarGroup = buildCarMesh({
        ...randomConfig,
        // Make glowing neon underglow rare for traffic unless Night mode
        glowingNeon: currentRoad.decorations === 'night' ? '#ff00ff' : undefined,
        hasSpoiler: Math.random() > 0.5,
        color: ['#ffffff', '#1a1a1a', '#e60000', '#0055ff', '#ffcc00', '#00ff33', '#8b0000'][Math.floor(Math.random() * 7)]
      });

      // Position far in front initially
      const lane = Math.floor(Math.random() * 3);
      const z = -60 - t * 25; // Staggered spawn positions
      trafficCarGroup.position.set(lanePositions[lane], 0, z);
      
      // Rotate traffic car to drive down the highway (180 degrees)
      trafficCarGroup.rotation.y = Math.PI;

      scene.add(trafficCarGroup);
      trafficPool.push({
        mesh: trafficCarGroup,
        lane,
        z,
        // Speed of opponent driving towards us or cruising slower
        speed: 0.1 + Math.random() * 0.15,
        colorHex: randomConfig.color
      });
    }

    // --- SPARK AND SMOKE PARTICLE SYSTEMS ---
    const sparkCount = 35;
    const sparkGeometry = new THREE.BufferGeometry();
    const sparkPositions = new Float32Array(sparkCount * 3);
    const sparkVelocities: THREE.Vector3[] = [];

    for (let i = 0; i < sparkCount; i++) {
      sparkPositions[i * 3] = 0;
      sparkPositions[i * 3 + 1] = 0;
      sparkPositions[i * 3 + 2] = 0;
      sparkVelocities.push(new THREE.Vector3(0, 0, 0));
    }

    sparkGeometry.setAttribute('position', new THREE.BufferAttribute(sparkPositions, 3));
    const sparkMaterial = new THREE.PointsMaterial({
      color: '#ffcc00',
      size: 0.25,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });
    const sparkPoints = new THREE.Points(sparkGeometry, sparkMaterial);
    sparkPoints.visible = false;
    scene.add(sparkPoints);

    // Smoke particles for tire drifting / burnout / engine damage
    const smokeCount = 30;
    const smokeGeometry = new THREE.BufferGeometry();
    const smokePositions = new Float32Array(smokeCount * 3);
    const smokeSizes = new Float32Array(smokeCount);
    const smokeAges: number[] = [];
    const smokeVelocities: THREE.Vector3[] = [];

    for (let i = 0; i < smokeCount; i++) {
      smokePositions[i * 3] = 0;
      smokePositions[i * 3 + 1] = 0;
      smokePositions[i * 3 + 2] = 0;
      smokeSizes[i] = 0.5;
      smokeAges.push(-1.0); // inactive
      smokeVelocities.push(new THREE.Vector3(0, 0, 0));
    }

    smokeGeometry.setAttribute('position', new THREE.BufferAttribute(smokePositions, 3));
    const smokeMaterial = new THREE.PointsMaterial({
      color: '#cccccc',
      size: 0.45,
      transparent: true,
      opacity: 0.35,
      depthWrite: false
    });
    const smokePoints = new THREE.Points(smokeGeometry, smokeMaterial);
    scene.add(smokePoints);

    // --- COINS OBJECT POOL AND SPARKLES ---
    const coinsPool: { mesh: THREE.Group; shadowMesh: THREE.Mesh; lane: number; z: number; active: boolean }[] = [];

    for (let c = 0; c < 15; c++) {
      const coinGrp = new THREE.Group();
      
      // Outer golden/orange disc (borders)
      const coinMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.35, 0.35, 0.08, 16),
        new THREE.MeshStandardMaterial({
          color: '#FFA500', // Beautiful orange border
          metalness: 0.9,
          roughness: 0.15,
          emissive: '#FF4500',
          emissiveIntensity: 0.2
        })
      );
      coinMesh.rotation.x = Math.PI / 2;
      coinMesh.castShadow = true;
      coinGrp.add(coinMesh);

      // Inner details / shiny bright gold core
      const innerMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.28, 0.28, 0.09, 16), // slightly thicker flat face so it protrudes past the border
        new THREE.MeshStandardMaterial({
          color: '#FFD700', // Bright Gold!
          metalness: 1.0,
          roughness: 0.05,
          emissive: '#FF8C00', // Amber/orange emissive highlight for rich glow
          emissiveIntensity: 0.35
        })
      );
      innerMesh.rotation.x = Math.PI / 2;
      coinGrp.add(innerMesh);

      coinGrp.position.set(0, -999, 0); // Hide initially
      scene.add(coinGrp);

      // Create a soft contact shadow mesh directly below the coin to make it stand out on all roads
      const shadowMesh = new THREE.Mesh(
        new THREE.CircleGeometry(0.35, 16),
        new THREE.MeshBasicMaterial({
          color: 0x000000,
          transparent: true,
          opacity: 0.45,
          depthWrite: false
        })
      );
      shadowMesh.rotation.x = -Math.PI / 2;
      shadowMesh.position.set(0, -999, 0); // Hide initially
      scene.add(shadowMesh);

      coinsPool.push({
        mesh: coinGrp,
        shadowMesh: shadowMesh,
        lane: 0,
        z: -999,
        active: false
      });
    }

    // Coin Sparkle Particles
    const coinSparkCount = 15;
    const coinSparkGeometry = new THREE.BufferGeometry();
    const coinSparkPositions = new Float32Array(coinSparkCount * 3);
    const coinSparkVelocities: THREE.Vector3[] = [];
    for (let i = 0; i < coinSparkCount; i++) {
      coinSparkPositions[i * 3] = 0;
      coinSparkPositions[i * 3 + 1] = 0;
      coinSparkPositions[i * 3 + 2] = 0;
      coinSparkVelocities.push(new THREE.Vector3(0, 0, 0));
    }
    coinSparkGeometry.setAttribute('position', new THREE.BufferAttribute(coinSparkPositions, 3));
    const coinSparkMaterial = new THREE.PointsMaterial({
      color: '#fbbf24', // golden shine
      size: 0.35,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });
    const coinSparkPoints = new THREE.Points(coinSparkGeometry, coinSparkMaterial);
    coinSparkPoints.visible = false;
    scene.add(coinSparkPoints);

    const triggerCoinSparkles = (posX: number, posY: number, posZ: number) => {
      coinSparkPoints.position.set(posX, posY, posZ);
      coinSparkPoints.visible = true;
      const positions = coinSparkGeometry.attributes.position.array as Float32Array;
      for (let i = 0; i < coinSparkCount; i++) {
        positions[i * 3] = 0;
        positions[i * 3 + 1] = 0;
        positions[i * 3 + 2] = 0;
        
        // Random golden explosion velocity
        coinSparkVelocities[i].set(
          (Math.random() - 0.5) * 4.0,
          (Math.random() - 0.5) * 4.0 + 2.0,
          (Math.random() - 0.5) * 4.0
        );
      }
      coinSparkGeometry.attributes.position.needsUpdate = true;
    };

    const triggerSparks = (posX: number, posZ: number) => {
      sparkPoints.position.set(posX, 0.4, posZ);
      sparkPoints.visible = true;
      const positions = sparkGeometry.attributes.position.array as Float32Array;
      
      for (let i = 0; i < sparkCount; i++) {
        positions[i * 3] = 0;
        positions[i * 3 + 1] = 0;
        positions[i * 3 + 2] = 0;
        
        // Random explosion velocity
        sparkVelocities[i].set(
          (Math.random() - 0.5) * 8.0,
          (Math.random() + 0.1) * 6.0,
          (Math.random() - 0.5) * 8.0
        );
      }
      sparkGeometry.attributes.position.needsUpdate = true;
    };

    const spawnSmoke = (posX: number, posZ: number, count: number = 1) => {
      const positions = smokeGeometry.attributes.position.array as Float32Array;
      let spawned = 0;
      for (let i = 0; i < smokeCount; i++) {
        if (smokeAges[i] < 0) {
          smokeAges[i] = 0; // mark active
          positions[i * 3] = posX + (Math.random() - 0.5) * 0.4;
          positions[i * 3 + 1] = 0.15;
          positions[i * 3 + 2] = posZ + (Math.random() - 0.5) * 0.4;
          
          smokeVelocities[i].set(
            (Math.random() - 0.5) * 0.8,
            0.15 + Math.random() * 0.4,
            1.5 + Math.random() * 2.0 // moves backward
          );
          spawned++;
          if (spawned >= count) break;
        }
      }
      smokeGeometry.attributes.position.needsUpdate = true;
    };

    // --- GAME ENGINE LOOP STATE VARIABLES ---
    let animationFrameId: number;
    let lastTime = performance.now();
    let collisionCooldown = 0;
    
    // Set initial dynamic speed multiplier
    stateRef.current.speedFactor = 0.0;
    stateRef.current.speed = 0;
    stateRef.current.distance = 0;
    stateRef.current.score = 0;
    stateRef.current.playerX = 0;
    stateRef.current.targetPlayerX = 0;
    stateRef.current.isWrecked = false;

    // Reset traffic
    trafficPool.forEach((tCar, idx) => {
      const lane = Math.floor(Math.random() * 3);
      const z = -65 - idx * 28;
      tCar.z = z;
      tCar.lane = lane;
      tCar.mesh.position.set(lanePositions[lane], 0, z);
    });

    const updatePhysics = (deltaTime: number) => {
      const state = stateRef.current;
      if (state.gameState !== 'playing') return;

      if (state.shouldReset) {
        state.shouldReset = false;
        state.isWrecked = false;
        state.speedFactor = 0.0;
        state.speed = 0;
        state.distance = 0;
        state.score = 0;
        state.playerX = 0;
        state.targetPlayerX = 0;
        state.roadOffset = 0;
        
        // Reset Nitro & Coins stats
        state.coinsCollected = 0;
        state.nitroCharge = 0.0;
        state.isNitroActive = false;
        state.nitroTimer = 0.0;
        state.gameTime = 0.0;
        state.isNitroRequested = false;

        // Reset player car group position and rotation
        playerCarGroup.position.set(0, 0, 0);
        playerCarGroup.rotation.set(0, 0, 0);

        // Reset traffic pool
        trafficPool.forEach((tCar, idx) => {
          const lane = Math.floor(Math.random() * 3);
          const z = -65 - idx * 28;
          tCar.z = z;
          tCar.lane = lane;
          tCar.mesh.position.set(lanePositions[lane], 0, z);
          tCar.mesh.rotation.set(0, Math.PI, 0);
        });

        // Hide road coins on reset
        coinsPool.forEach(coin => {
          coin.z = -999;
          coin.active = false;
          coin.mesh.visible = false;
          coin.mesh.position.set(0, -999, 0);
          if (coin.shadowMesh) {
            coin.shadowMesh.visible = false;
            coin.shadowMesh.position.set(0, -999, 0);
          }
        });

        // Hide sparks and sparkles
        sparkPoints.visible = false;
        coinSparkPoints.visible = false;

        // Reset smoke
        for (let i = 0; i < smokeCount; i++) {
          smokeAges[i] = -1.0;
          const pos = smokeGeometry.attributes.position.array as Float32Array;
          pos[i * 3] = 9999;
          pos[i * 3 + 1] = 0;
          pos[i * 3 + 2] = 0;
        }
        smokeGeometry.attributes.position.needsUpdate = true;
      }

      if (state.isWrecked) {
        // Slowing down after crash
        state.speedFactor *= 0.94;
        state.speed = Math.floor(state.speedFactor * 140);
        soundManager.setEngineSpeed(0.0);
        return;
      }

      // 1. Accumulate elapsed game time and calculate smooth difficulty scaling
      state.gameTime += deltaTime;
      
      // Calculate smooth difficulty factor: first 20s rises very slowly for beginners, then increases gradually up to 3.0
      let difficultyFactor = 0.0;
      if (state.gameTime <= 20.0) {
        difficultyFactor = (state.gameTime / 20.0) * 0.25;
      } else {
        difficultyFactor = 0.25 + Math.min(2.75, (state.gameTime - 20.0) / 10.0);
      }

      // Charge Nitro while driving (faster driving charges nitro faster, reduced by 35% for better gameplay balance)
      if (!state.isWrecked && !state.isNitroActive) {
        const chargingSpeed = (state.speedFactor * 12.0 + 2.5) * 0.65;
        state.nitroCharge = Math.min(100, state.nitroCharge + chargingSpeed * deltaTime);
      }

      // Activate Nitro if requested and fully charged
      if (state.isNitroRequested && state.nitroCharge >= 100 && !state.isNitroActive && !state.isWrecked) {
        state.isNitroActive = true;
        state.nitroTimer = 4.0; // 4 seconds duration
        state.isNitroRequested = false;
        soundManager.playNitroBoost();
        if (onNitroStarted) {
          onNitroStarted();
        }
      }

      // Accelerate speed gradually and clearly over time/distance, multiplied by Nitro if active
      let nitroMult = 1.0;
      if (state.isNitroActive) {
        nitroMult = 1.5;
        state.nitroTimer -= deltaTime;
        if (state.nitroTimer <= 0) {
          state.isNitroActive = false;
          state.nitroCharge = 0.0; // fully consumed, reset to 0
        }
      }

      const speedDifficulty = Math.min(0.9, difficultyFactor * 0.12);
      const targetSpeedFactor = (0.56 + speedDifficulty) * nitroMult; // Reduced starting speed from 0.65 to 0.56 (~14% reduction)
      const lerpFactor = state.isNitroActive ? 0.08 : 0.02;
      state.speedFactor = THREE.MathUtils.lerp(state.speedFactor, targetSpeedFactor, lerpFactor);
      
      // Calculate display speed (MPH)
      state.speed = Math.floor(state.speedFactor * 220);
      
      // Update engine audio pitch real-time
      soundManager.setEngineSpeed(state.speed / 230);

      // 2. Continuous side steering interpolation
      // Check keyboard arrows first
      if (state.keys.left) {
        state.targetPlayerX = Math.max(-3.2, state.targetPlayerX - 0.16 * state.settings.sensitivity);
      }
      if (state.keys.right) {
        state.targetPlayerX = Math.min(3.2, state.targetPlayerX + 0.16 * state.settings.sensitivity);
      }

      // Smooth horizontal interpolation for steering
      const steeringSpeed = 0.14 * (1.0 + currentCar.handling * 0.003); // car config handling boost
      const prevX = state.playerX;
      state.playerX = THREE.MathUtils.lerp(state.playerX, state.targetPlayerX, steeringSpeed);
      playerCarGroup.position.x = state.playerX;
      
      // Dynamic tilting angle when steering
      const tiltAngle = (state.playerX - prevX) * 0.75;
      playerCarGroup.rotation.y = -tiltAngle;
      playerCarGroup.rotation.z = -tiltAngle * 1.5;

      // Update tail exhaust jet flames
      if (state.isNitroActive) {
        flameGroup.visible = true;
        const scale = 0.8 + Math.random() * 0.4;
        leftFlame.scale.set(scale, scale * 1.5, scale);
        rightFlame.scale.set(scale, scale * 1.5, scale);
        flameMat.color.set(Math.random() > 0.45 ? '#06b6d4' : '#f43f5e'); // cyan/magenta flicker
        
        // Eject smoke trail
        spawnSmoke(state.playerX - 0.4, 1.6, 1);
        spawnSmoke(state.playerX + 0.4, 1.6, 1);
      } else {
        flameGroup.visible = false;
      }

      // Spawn drifting tire smoke if steering hard
      if (Math.abs(tiltAngle) > 0.015 && Math.random() > 0.3) {
        spawnSmoke(state.playerX, 1.2, 1);
        if (Math.random() > 0.85) {
          soundManager.playBrakeSqueal();
        }
      }

      // 3. Scroll road segments backwards (Endless effect)
      state.roadOffset += state.speedFactor * 60 * deltaTime;
      const roadZ = state.roadOffset % segmentLength;
      
      roadSegments.forEach((segment, idx) => {
        // Position segments infinitely
        const rawZ = -idx * segmentLength + roadZ;
        // Wrap segment around
        if (rawZ > segmentLength) {
          segment.position.z = rawZ - totalSegments * segmentLength;
        } else {
          segment.position.z = rawZ;
        }
      });

      // 4. Update roadside decorations relative to road speed
      sideObjectsPool.forEach(item => {
        item.relZ += state.speedFactor * 60 * deltaTime;
        if (item.relZ > 12) {
          item.relZ = -150 - Math.random() * 20;
          // Randomize X offset side
          const offsetDist = decorationType === 'city' || decorationType === 'night' ? 6.5 : 5.8;
          const sideX = item.side === 'left' ? -offsetDist - Math.random() * 8 : offsetDist + Math.random() * 8;
          item.mesh.position.x = sideX;
        }
        item.mesh.position.z = item.relZ;
      });

      // 5. Update traffic cars with dynamic density and speed scaling (Difficulty)
      // Active traffic density starts at 3, increases by 1 for every 20 seconds, capped at 6.
      const activeTrafficCount = Math.min(6, 3 + Math.floor(state.gameTime / 20.0));

      trafficPool.forEach((tCar, idx) => {
        if (idx >= activeTrafficCount) {
          tCar.mesh.visible = false;
          tCar.z = -999;
          tCar.mesh.position.set(0, -999, 0);
          return;
        }

        // If newly activated and was stored at -999, spawn it ahead
        if (tCar.z === -999) {
          tCar.z = -100 - idx * 25 - Math.random() * 20;
          tCar.lane = Math.floor(Math.random() * 3);
          tCar.mesh.position.set(lanePositions[tCar.lane], 0, tCar.z);
          tCar.mesh.visible = true;
        }

        // Move towards us - relative approach speed scales up with time-based difficulty
        const speedDifficultyMult = 1.0 + (difficultyFactor * 0.18);
        const relativeApproachSpeed = (state.speedFactor - tCar.speed) * speedDifficultyMult;
        tCar.z += relativeApproachSpeed * 60 * deltaTime;
        
        // Wrap traffic around to front once it goes past us
        if (tCar.z > 12) {
          tCar.z = -140 - Math.random() * 50;
          tCar.lane = Math.floor(Math.random() * 3);
          tCar.mesh.position.x = lanePositions[tCar.lane];
          
          // Randomize speed
          tCar.speed = 0.05 + Math.random() * 0.16;
        }
        tCar.mesh.position.z = tCar.z;

        // Wheel spinning visual effect
        tCar.mesh.children.forEach(child => {
          if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry && child.geometry.parameters.radiusTop === 0.38) {
            child.rotation.x -= 0.18;
          }
        });

        // 6. COLLISION DETECTION with traffic (Bounding Box / Distance threshold)
        if (!state.isWrecked && Math.abs(tCar.z) < 2.5) {
          const xDist = Math.abs(state.playerX - tCar.mesh.position.x);
          // Collision box: width threshold 1.35
          if (xDist < 1.35) {
            // CRASH IMPACT!
            state.isWrecked = true;
            soundManager.playCrash();
            
            // Trigger Phone Vibration if API is available
            if (navigator.vibrate) {
              navigator.vibrate([150, 80, 200, 100, 300]);
            }

            // Create spectacular spark explosion
            triggerSparks(state.playerX, tCar.z);

            // Stave off game loop and trigger callbacks with brief high-action cinematic delay
            setTimeout(() => {
              onCrash(state.score, Math.floor(state.distance), state.coinsCollected);
            }, 1800);
          }
        }
      });

      // 6.5. Update road gold coins with density scaling over distance
      // Density of coins increases as the round progresses (starts at 4, caps at 12 active)
      const activeCoinsCount = Math.min(12, 4 + Math.floor(state.distance / 120.0));
      coinsPool.forEach((coin, idx) => {
        if (idx >= activeCoinsCount) {
          coin.mesh.visible = false;
          coin.active = false;
          coin.z = -999;
          coin.mesh.position.set(0, -999, 0);
          if (coin.shadowMesh) {
            coin.shadowMesh.visible = false;
            coin.shadowMesh.position.set(0, -999, 0);
          }
          return;
        }

        // Just activated, spawn ahead of player
        if (coin.z === -999) {
          coin.z = -40 - idx * 12 - Math.random() * 15;
          coin.lane = Math.floor(Math.random() * 3);
          coin.mesh.position.x = lanePositions[coin.lane];
          coin.active = true;
          coin.mesh.visible = true;
          if (coin.shadowMesh) {
            coin.shadowMesh.visible = true;
            coin.shadowMesh.position.x = lanePositions[coin.lane];
          }
        }

        // Move coins towards the player
        coin.z += state.speedFactor * 60 * deltaTime;
        coin.mesh.position.z = coin.z;
        // Float coin up and down elegantly
        coin.mesh.position.y = 0.5 + Math.sin(performance.now() * 0.005 + idx) * 0.12;
        // Spin coin rapidly
        coin.mesh.rotation.y += deltaTime * 3.5;

        // Position and scale shadow mesh flat on the ground below the floating coin
        if (coin.shadowMesh && coin.active) {
          coin.shadowMesh.position.set(coin.mesh.position.x, 0.015, coin.z);
          coin.shadowMesh.visible = true;
          
          // Shrink and fade shadow slightly as coin floats higher
          const heightDiff = coin.mesh.position.y - 0.5;
          const shadowScale = Math.max(0.6, 1.0 - heightDiff * 0.55);
          coin.shadowMesh.scale.set(shadowScale, shadowScale, 1.0);
          
          if (!Array.isArray(coin.shadowMesh.material) && coin.shadowMesh.material) {
            coin.shadowMesh.material.opacity = Math.max(0.15, 0.45 - heightDiff * 0.4);
          }
        }

        // Wrap around to front if past us
        if (coin.z > 12) {
          coin.z = -120 - Math.random() * 80;
          coin.lane = Math.floor(Math.random() * 3);
          coin.mesh.position.x = lanePositions[coin.lane];
          coin.active = true;
          coin.mesh.visible = true;
          if (coin.shadowMesh) {
            coin.shadowMesh.visible = true;
            coin.shadowMesh.position.x = lanePositions[coin.lane];
          }
        }

        // Collision detection for coin pick-up
        if (coin.active && !state.isWrecked && Math.abs(coin.z) < 1.6) {
          const xDist = Math.abs(state.playerX - coin.mesh.position.x);
          if (xDist < 1.0) {
            coin.active = false;
            coin.mesh.visible = false;
            if (coin.shadowMesh) {
              coin.shadowMesh.visible = false;
              coin.shadowMesh.position.set(0, -999, 0);
            }
            soundManager.playCoinCollect();
            state.coinsCollected++;
            triggerCoinSparkles(coin.mesh.position.x, coin.mesh.position.y, coin.z);
          }
        }
      });

      // 7. Update Distance and Score
      state.distance += state.speedFactor * 1.8 * deltaTime;
      const oldScore = state.score;
      state.score = Math.floor(state.distance * 10);
      
      // Play chime on score milestone
      if (Math.floor(state.score / 1000) > Math.floor(oldScore / 1000)) {
        soundManager.playScoreBeep();
      }

      // Broadcast score, speed, coins, and nitro updates up to HUD
      if (onUpdateHUD) {
        onUpdateHUD(state.score, state.speed, state.coinsCollected, Math.floor(state.nitroCharge), state.isNitroActive);
      } else {
        onUpdateScore(state.score, state.speed);
      }
    };

    const updateParticles = (deltaTime: number) => {
      // Update sparks
      if (sparkPoints.visible) {
        const positions = sparkGeometry.attributes.position.array as Float32Array;
        let activeSparks = 0;
        
        for (let i = 0; i < sparkCount; i++) {
          // Apply velocity
          positions[i * 3] += sparkVelocities[i].x * deltaTime;
          positions[i * 3 + 1] += sparkVelocities[i].y * deltaTime;
          positions[i * 3 + 2] += sparkVelocities[i].z * deltaTime;
          
          // Apply gravity
          sparkVelocities[i].y -= 9.8 * deltaTime;
          
          // Bounce sparks off ground
          if (positions[i * 3 + 1] < -0.3) {
            positions[i * 3 + 1] = -0.3;
            sparkVelocities[i].y = -sparkVelocities[i].y * 0.4; // dampening
          }
          
          if (sparkVelocities[i].length() > 0.1) activeSparks++;
        }
        sparkGeometry.attributes.position.needsUpdate = true;
        if (activeSparks === 0) sparkPoints.visible = false;
      }

      // Update coin sparkles
      if (coinSparkPoints.visible) {
        const positions = coinSparkGeometry.attributes.position.array as Float32Array;
        let activeCoinSparks = 0;
        
        for (let i = 0; i < coinSparkCount; i++) {
          positions[i * 3] += coinSparkVelocities[i].x * deltaTime;
          positions[i * 3 + 1] += coinSparkVelocities[i].y * deltaTime;
          positions[i * 3 + 2] += coinSparkVelocities[i].z * deltaTime;
          
          // Apply gravity
          coinSparkVelocities[i].y -= 4.0 * deltaTime;
          
          if (coinSparkVelocities[i].length() > 0.05) activeCoinSparks++;
        }
        coinSparkGeometry.attributes.position.needsUpdate = true;
        if (activeCoinSparks === 0) coinSparkPoints.visible = false;
      }

      // Update smoke
      const smokePositionsArray = smokeGeometry.attributes.position.array as Float32Array;
      for (let i = 0; i < smokeCount; i++) {
        if (smokeAges[i] >= 0) {
          smokeAges[i] += deltaTime;
          
          // Apply drift velocity
          smokePositionsArray[i * 3] += smokeVelocities[i].x * deltaTime;
          smokePositionsArray[i * 3 + 1] += smokeVelocities[i].y * deltaTime;
          smokePositionsArray[i * 3 + 2] += smokeVelocities[i].z * deltaTime;
          
          // Fade out smoke
          if (smokeAges[i] > 0.8) {
            smokeAges[i] = -1.0; // deactivate
            smokePositionsArray[i * 3] = 9999; // hide
          }
        }
      }
      smokeGeometry.attributes.position.needsUpdate = true;
    };

    // Spin player wheels
    const animatePlayerWheels = () => {
      playerCarGroup.children.forEach(child => {
        // Select wheel cylinders based on matching radiusTop parameter from CylinderGeometry
        if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry && child.geometry.parameters.radiusTop === 0.38) {
          child.rotation.x -= stateRef.current.speedFactor * 0.9;
        }
      });
    };

    // Camera bounce and shake feedback
    const updateCameraEffects = (time: number) => {
      const state = stateRef.current;
      if (state.gameState === 'playing' && !state.isWrecked) {
        // High-speed wind/rumble camera vibration
        const rumbleAmp = state.speedFactor * 0.015;
        camera.position.x = Math.sin(time * 50) * rumbleAmp;
        camera.position.y = 3.8 + Math.cos(time * 42) * rumbleAmp;
        
        // FOV widening on speed acceleration (simulating motion blur look)
        camera.fov = 60 + state.speedFactor * 12;
        camera.updateProjectionMatrix();
      } else if (state.isWrecked) {
        // Dramatic heavy impact crash shake
        const decay = Math.max(0, 1.8 - (performance.now() - lastTime) / 1000);
        const shake = Math.sin(time * 90) * 0.28;
        camera.position.set(shake, 3.8 + Math.cos(time * 75) * 0.28, 6.5);
      }
    };

    // Render loop
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      
      const now = performance.now();
      const deltaTime = Math.min((now - lastTime) / 1000, 0.1); // Clamp dt to prevent massive jumps
      lastTime = now;

      // Update state machine
      updatePhysics(deltaTime);
      updateParticles(deltaTime);
      animatePlayerWheels();
      updateCameraEffects(now / 1000);

      // Simple rotation of player car in main menu for gorgeous showroom showcase
      if (stateRef.current.gameState === 'menu') {
        playerCarGroup.rotation.y = now * 0.0008;
        // Float showroom style
        playerCarGroup.position.y = Math.sin(now * 0.002) * 0.08 + 0.1;
        playerCarGroup.position.x = 0;
        
        // Rotate showroom wheels slowly
        playerCarGroup.children.forEach(child => {
          if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry && child.geometry.parameters.radiusTop === 0.38) {
            child.rotation.x -= 0.02;
          }
        });
        
        // Showroom camera angle
        camera.position.set(3.2, 2.2, 5.0);
        camera.lookAt(0, 0.5, 0);
        camera.fov = 55;
        camera.updateProjectionMatrix();
      } else if (stateRef.current.gameState === 'playing') {
        // Game camera defaults
        camera.position.z = 6.5;
        camera.lookAt(stateRef.current.playerX * 0.7, 1.1, -6);
      }

      renderer.render(scene, camera);
    };

    animate();

    // Resize observer to auto-adapt to responsive viewport dimensions (Canvas mobile sizing)
    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width: newWidth, height: newHeight } = entries[0].contentRect;
      
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    });
    
    resizeObserver.observe(container);

    // Clean up
    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      renderer.dispose();
      
      // Dispose materials
      roadMaterial.dispose();
      shoulderMaterial.dispose();
      laneLineMaterial.dispose();
      
      // Stop sequencer
      soundManager.stopEngine();
    };
  }, [selectedCarId, selectedRoadId, settings.graphicsQuality]);

  return (
    <div id="canvas-container" ref={containerRef} className="w-full h-full relative overflow-hidden bg-slate-950">
      <canvas id="game-canvas" ref={canvasRef} className="w-full h-full block cursor-pointer select-none touch-none" />
    </div>
  );
};

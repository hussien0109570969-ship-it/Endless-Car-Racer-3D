/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Trophy, RotateCcw, Home, Star, ChevronLeft } from 'lucide-react';

interface GameOverProps {
  score: number;
  distance: number;
  highScore: number;
  isNewRecord: boolean;
  onRestart: () => void;
  onGoHome: () => void;
  coinsEarned: number;
}

export const GameOver: React.FC<GameOverProps> = ({
  score,
  distance,
  highScore,
  isNewRecord,
  onRestart,
  onGoHome,
  coinsEarned
}) => {
  return (
    <div id="game-over-overlay" className="absolute inset-0 z-30 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-white font-sans select-none">
      
      {/* Container Card */}
      <div className="bg-slate-950 border border-white/10 rounded-3xl p-6 md:p-8 max-w-sm w-full text-center shadow-[0_20px_50px_rgba(239,68,68,0.25)] relative overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Absolute Glowing background accents */}
        <div className="absolute -top-12 -left-12 w-24 h-24 bg-rose-600/20 blur-2xl rounded-full" />
        <div className="absolute -bottom-12 -right-12 w-24 h-24 bg-amber-500/20 blur-2xl rounded-full" />

        {/* Title Indicator */}
        <div className="flex flex-col items-center mb-6">
          <div className="w-16 h-16 bg-rose-600/15 border border-rose-500/20 rounded-full flex items-center justify-center mb-3 text-rose-500 animate-bounce">
            <Trophy className="w-8 h-8" />
          </div>
          <h2 className="text-3xl font-black uppercase text-white tracking-wide">انتهى السباق</h2>
          <p className="text-xs text-rose-500 font-bold uppercase mt-1">Game Over</p>
        </div>

        {/* New Record Banner */}
        {isNewRecord && (
          <div className="bg-gradient-to-r from-amber-500 to-rose-500 text-black font-black text-sm px-4 py-2 rounded-xl mb-6 shadow-md flex items-center justify-center gap-1.5 animate-pulse">
            <Star className="w-4 h-4 fill-current" />
            <span>رقم قياسي جديد! (New Record)</span>
            <Star className="w-4 h-4 fill-current" />
          </div>
        )}

        {/* Statistics Breakdown */}
        <div className="bg-white/5 border border-white/5 rounded-2xl p-4 flex flex-col gap-3 mb-6">
          
          {/* Final Score */}
          <div className="flex justify-between items-center border-b border-white/5 pb-2">
            <span className="text-sm text-gray-400 font-medium">النقاط الكلية:</span>
            <span className="text-2xl font-black font-mono text-cyan-400">{score.toLocaleString()}</span>
          </div>

          {/* Coins Earned */}
          <div className="flex justify-between items-center border-b border-white/5 pb-2">
            <span className="text-sm text-gray-400 font-medium">العملات المكتسبة:</span>
            <span className="text-xl font-black font-mono text-amber-400">🪙 +{coinsEarned}</span>
          </div>

          {/* Distance Driven */}
          <div className="flex justify-between items-center border-b border-white/5 pb-2">
            <span className="text-sm text-gray-400 font-medium">المسافة المقطوعة:</span>
            <span className="text-lg font-black font-mono text-slate-200">{distance} م</span>
          </div>

          {/* Personal Best High Score */}
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400 font-medium">أفضل نتيجة مسجلة:</span>
            <span className="text-lg font-black font-mono text-amber-400">{highScore.toLocaleString()}</span>
          </div>

        </div>

        {/* Action button controls */}
        <div className="flex flex-col gap-3">
          
          {/* Quick Restart */}
          <button
            id="restart-after-gameover-btn"
            onClick={onRestart}
            className="w-full py-4 bg-gradient-to-r from-rose-600 to-amber-500 hover:from-rose-500 hover:to-amber-400 text-white font-black rounded-2xl shadow-[0_4px_15px_rgba(239,68,68,0.3)] transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-5 h-5" />
            إعادة السباق
          </button>

          {/* Go Back Home */}
          <button
            id="gohome-after-gameover-btn"
            onClick={onGoHome}
            className="w-full py-3 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Home className="w-4 h-4" />
            العودة للقائمة الرئيسية
          </button>

        </div>

      </div>

    </div>
  );
};

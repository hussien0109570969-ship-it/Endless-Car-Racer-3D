/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { Pause, Play, Home, Volume2, VolumeX } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GameHUDProps {
  score: number;
  speed: number;
  coinsCollected?: number;
  nitroCharge?: number;
  isNitroActive?: boolean;
  onTriggerNitro?: () => void;
  onPause: () => void;
  isPaused: boolean;
  onRestart: () => void;
  onGoHome: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  score,
  speed,
  coinsCollected = 0,
  nitroCharge = 0,
  isNitroActive = false,
  onTriggerNitro,
  onPause,
  isPaused,
  onRestart,
  onGoHome,
  soundEnabled,
  onToggleSound
}) => {
  // Determine realistic automatic gear shifts based on current speed
  const gear = useMemo(() => {
    if (speed < 5) return 'N';
    if (speed < 45) return '1';
    if (speed < 85) return '2';
    if (speed < 125) return '3';
    if (speed < 170) return '4';
    return '5'; // Top speed sports gear
  }, [speed]);

  // Calculate dynamic RPM ratio (simulate sports engine redline bouncing at high speeds)
  const rpmRatio = useMemo(() => {
    if (speed < 5) return 0.1;
    // Simulate gear-based RPM curve
    let gearMax = 45;
    let gearMin = 0;
    if (speed >= 45 && speed < 85) { gearMin = 45; gearMax = 85; }
    else if (speed >= 85 && speed < 125) { gearMin = 85; gearMax = 125; }
    else if (speed >= 125 && speed < 170) { gearMin = 125; gearMax = 170; }
    else if (speed >= 170) { gearMin = 170; gearMax = 220; }

    const ratio = (speed - gearMin) / (gearMax - gearMin || 1);
    // Add subtle procedural vibration/jitter near redline (ratio > 0.85)
    const jitter = ratio > 0.85 ? (Math.sin(Date.now() * 0.1) * 0.03) : 0;
    return Math.min(1.0, Math.max(0.1, ratio + 0.1 + jitter));
  }, [speed]);

  return (
    <div id="game-hud" className="absolute inset-0 z-10 flex flex-col justify-between p-4 pointer-events-none text-white select-none">
      
      {/* Top Section containing Score, Speedometer, and Controls */}
      <div className="w-full max-w-lg mx-auto flex flex-col gap-2.5 pointer-events-auto">
        
        {/* Header - Score, Coins & Quick Audio/Pause Buttons */}
        <header className="flex justify-between items-center w-full">
          <div className="flex gap-2">
            {/* Real-time Score Badge */}
            <div className="bg-black/60 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-white/10 flex flex-col">
              <span className="text-[9px] text-cyan-400 font-bold tracking-wider uppercase text-right">النقاط</span>
              <span className="text-xl font-black font-mono leading-none">{score.toLocaleString()}</span>
            </div>

            {/* Real-time Coins collected */}
            <div className="bg-black/60 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-white/10 flex flex-col">
              <span className="text-[9px] text-amber-400 font-bold tracking-wider uppercase text-right flex items-center gap-1 justify-end">
                العملات
              </span>
              <span className="text-xl font-black font-mono leading-none text-amber-400 flex items-center gap-1 justify-end">
                🪙 {coinsCollected}
              </span>
            </div>
          </div>

          {/* HUD Quick Controls */}
          <div className="flex gap-2">
            {/* Audio Quick Toggle */}
            <button
              id="hud-mute-btn"
              onClick={onToggleSound}
              className="w-10 h-10 flex items-center justify-center bg-black/60 backdrop-blur-md rounded-xl border border-white/10 hover:bg-white/20 active:scale-95 transition-all cursor-pointer"
            >
              {soundEnabled ? <Volume2 className="w-5 h-5 text-cyan-400" /> : <VolumeX className="w-5 h-5 text-gray-500" />}
            </button>

            {/* Pause Trigger */}
            <button
              id="hud-pause-btn"
              onClick={onPause}
              className="w-10 h-10 flex items-center justify-center bg-black/60 backdrop-blur-md rounded-xl border border-white/10 hover:bg-white/20 active:scale-95 transition-all cursor-pointer"
            >
              <Pause className="w-5 h-5 text-white" />
            </button>
          </div>
        </header>

        {/* Compact, non-blocking Speedometer & RPM Bar at the TOP */}
        <div className="w-full bg-black/70 backdrop-blur-md border border-white/10 rounded-2xl p-2.5 px-3 shadow-lg flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-3 duration-200">
          {/* Speed Digital Readout & Gear */}
          <div className="flex items-center gap-2">
            <div className="bg-slate-900/90 border border-white/5 rounded-lg px-2 py-1 flex flex-col items-center justify-center min-w-[58px]">
              <span className="text-base font-black font-mono text-white leading-none">{speed}</span>
              <span className="text-[8px] text-gray-400 font-bold tracking-wider uppercase">MPH</span>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-900/90 border border-white/5 rounded-lg px-2 py-1">
              <span className="text-[8px] text-gray-500 font-bold uppercase">الترس</span>
              <span className="text-sm font-black font-mono text-cyan-400">{gear}</span>
            </div>
          </div>

          {/* RPM / TACHOMETER Progress String */}
          <div className="flex-1 flex flex-col justify-center">
            <div className="flex justify-between items-center text-[8px] text-gray-400 mb-0.5 font-bold">
              <span>RPM / TACHOMETER</span>
              <span className={rpmRatio > 0.82 ? "text-rose-500 animate-pulse font-mono font-bold" : "text-cyan-400 font-mono"}>
                {(rpmRatio * 9000).toFixed(0)} RPM
              </span>
            </div>
            <div className="flex gap-0.5 h-2.5 bg-slate-950/60 p-0.5 rounded border border-white/5">
              {Array.from({ length: 14 }).map((_, i) => {
                const threshold = i / 14;
                const active = rpmRatio >= threshold;
                const isRedline = i >= 11;
                
                return (
                  <div
                    key={i}
                    className={`flex-1 rounded-sm transition-all ${
                      active 
                        ? isRedline 
                          ? 'bg-rose-500 shadow-[0_0_5px_rgba(239,68,68,0.6)]' 
                          : 'bg-cyan-400 shadow-[0_0_3px_rgba(34,211,238,0.4)]'
                        : 'bg-slate-800'
                    }`}
                  />
                );
              })}
            </div>
          </div>
        </div>

      </div>

      {/* Speed lines / Motion Blur overlay when Nitro is Active */}
      {isNitroActive && (
        <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden mix-blend-screen opacity-60">
          <div className="absolute inset-0 bg-[radial-gradient(circle,transparent_45%,rgba(6,182,212,0.18)_100%)]" />
          {/* Left flowing streaks */}
          <div className="absolute top-0 bottom-0 left-0 w-20 bg-gradient-to-r from-cyan-400/20 to-transparent flex flex-col justify-around py-8 pl-4">
            <div className="h-[2px] w-12 bg-white/50 rounded-full animate-pulse" />
            <div className="h-[2px] w-20 bg-cyan-300/50 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
            <div className="h-[2px] w-14 bg-white/40 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
            <div className="h-[2px] w-24 bg-cyan-300/40 rounded-full animate-pulse" style={{ animationDelay: '0.1s' }} />
          </div>
          {/* Right flowing streaks */}
          <div className="absolute top-0 bottom-0 right-0 w-20 bg-gradient-to-l from-cyan-400/20 to-transparent flex flex-col justify-around py-8 pr-4 items-end">
            <div className="h-[2px] w-16 bg-white/50 rounded-full animate-pulse" style={{ animationDelay: '0.15s' }} />
            <div className="h-[2px] w-24 bg-cyan-300/50 rounded-full animate-pulse" style={{ animationDelay: '0.05s' }} />
            <div className="h-[2px] w-10 bg-white/40 rounded-full animate-pulse" style={{ animationDelay: '0.3s' }} />
            <div className="h-[2px] w-20 bg-cyan-300/40 rounded-full animate-pulse" style={{ animationDelay: '0.25s' }} />
          </div>
        </div>
      )}

      {/* Bottom Section - Nitro Boost Button */}
      <div className="w-full flex justify-end pointer-events-none mb-4 px-4">
        <div className="pointer-events-auto">
          <button
            id="hud-nitro-btn"
            onClick={onTriggerNitro}
            disabled={nitroCharge < 100 || isNitroActive}
            className={`w-18 h-18 rounded-full border flex flex-col items-center justify-center transition-all cursor-pointer shadow-2xl relative select-none ${
              isNitroActive
                ? 'bg-rose-500 border-rose-400 animate-pulse scale-105 text-white shadow-[0_0_20px_rgba(244,63,94,0.6)]'
                : nitroCharge >= 100
                  ? 'bg-gradient-to-br from-cyan-400 to-blue-600 border-cyan-300 scale-105 text-white shadow-[0_0_15px_rgba(34,211,238,0.5)] hover:brightness-110 active:scale-95 animate-bounce'
                  : 'bg-black/70 border-white/15 text-gray-500'
            }`}
          >
            {/* SVG Circular charge progress tracker */}
            <svg className="absolute inset-0 w-full h-full transform -rotate-90">
               <circle
                 cx="36"
                 cy="36"
                 r="32"
                 className="stroke-white/5 fill-none"
                 strokeWidth="3.5"
               />
               <circle
                 cx="36"
                 cy="36"
                 r="32"
                 className={`fill-none transition-all duration-300 ${
                   nitroCharge >= 100 ? 'stroke-cyan-400' : 'stroke-white/35'
                 }`}
                 strokeWidth="3.5"
                 strokeDasharray={2 * Math.PI * 32}
                 strokeDashoffset={2 * Math.PI * 32 * (1 - Math.min(100, Math.max(0, nitroCharge)) / 100)}
               />
            </svg>

            {/* Icon & Label */}
            <span className="text-xl z-10">{isNitroActive ? '🔥' : '⚡'}</span>
            <span className="text-[9px] font-black tracking-tighter leading-none z-10 mt-0.5">
              {isNitroActive ? 'نشط' : nitroCharge >= 100 ? 'اضغط' : `${nitroCharge}%`}
            </span>
          </button>
        </div>
      </div>

      {/* Floating Pause Dialog Modal (Animated overlay) */}
      <AnimatePresence>
        {isPaused && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 bg-black/60 backdrop-blur-md z-30 flex flex-col items-center justify-center p-6 pointer-events-auto"
          >
            <motion.div
              initial={{ scale: 0.9, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 15 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="bg-slate-900/90 border border-white/10 rounded-3xl p-6 text-center max-w-xs w-full shadow-2xl"
            >
              <h2 className="text-2xl font-black mb-1 text-white">السباق متوقف</h2>
              <p className="text-xs text-gray-400 mb-6">يمكنك استئناف الجولة الحالية أو العودة للرئيسية.</p>
              
              <div className="flex flex-col gap-3">
                {/* 1. Resume playing */}
                <button
                  id="resume-race-btn"
                  onClick={onPause}
                  className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-black rounded-xl hover:from-cyan-400 hover:to-blue-500 transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2 shadow-lg"
                >
                  <Play className="w-4 h-4 fill-current" />
                  استئناف اللعب (Resume)
                </button>

                {/* 2. Go back to Main Menu */}
                <button
                  id="gohome-race-btn"
                  onClick={onGoHome}
                  className="w-full py-3 bg-white/10 hover:bg-white/15 border border-white/10 text-white font-bold rounded-xl transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Home className="w-4 h-4" />
                  الرجوع للقائمة الرئيسية (Main Menu)
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};

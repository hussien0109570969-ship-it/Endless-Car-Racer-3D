/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CARS, ROADS, CarConfig, RoadConfig, GameSettings } from '../types';
import { Trophy, Play, Car, Map, Settings as SettingsIcon, Volume2, VolumeX, Flame, ChevronLeft, ChevronRight } from 'lucide-react';
import { soundManager } from '../soundManager';

interface MainMenuProps {
  highScore: number;
  lastScore: number;
  selectedCarId: string;
  selectedRoadId: string;
  settings: GameSettings;
  onStartGame: () => void;
  onSelectCar: (id: string) => void;
  onSelectRoad: (id: string) => void;
  onUpdateSettings: (settings: GameSettings) => void;
  coins: number;
  unlockedCarIds: string[];
  onBuyCar: (id: string, price: number) => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  highScore,
  lastScore,
  selectedCarId,
  selectedRoadId,
  settings,
  onStartGame,
  onSelectCar,
  onSelectRoad,
  onUpdateSettings,
  coins,
  unlockedCarIds,
  onBuyCar
}) => {
  const [activeTab, setActiveTab] = useState<'none' | 'garage' | 'roads' | 'settings'>('none');
  
  // Track selected indices for car/road slide preview
  const currentCarIndex = CARS.findIndex(c => c.id === selectedCarId);
  const currentRoadIndex = ROADS.findIndex(r => r.id === selectedRoadId);

  const selectedCar = CARS[currentCarIndex] || CARS[0];
  const selectedRoad = ROADS[currentRoadIndex] || ROADS[0];

  const handleNextCar = () => {
    const nextIdx = (currentCarIndex + 1) % CARS.length;
    onSelectCar(CARS[nextIdx].id);
    soundManager.playLaneChange();
  };

  const handlePrevCar = () => {
    const prevIdx = (currentCarIndex - 1 + CARS.length) % CARS.length;
    onSelectCar(CARS[prevIdx].id);
    soundManager.playLaneChange();
  };

  const handleNextRoad = () => {
    const nextIdx = (currentRoadIndex + 1) % ROADS.length;
    onSelectRoad(ROADS[nextIdx].id);
    soundManager.playLaneChange();
  };

  const handlePrevRoad = () => {
    const prevIdx = (currentRoadIndex - 1 + ROADS.length) % ROADS.length;
    onSelectRoad(ROADS[prevIdx].id);
    soundManager.playLaneChange();
  };

  const toggleSound = () => {
    const updated = { ...settings, soundEnabled: !settings.soundEnabled };
    onUpdateSettings(updated);
    soundManager.setSoundEnabled(updated.soundEnabled);
  };

  const toggleMusic = () => {
    const updated = { ...settings, musicEnabled: !settings.musicEnabled };
    onUpdateSettings(updated);
    soundManager.setMusicEnabled(updated.musicEnabled);
  };

  return (
    <div id="main-menu-overlay" className="absolute inset-0 z-20 flex flex-col justify-between p-6 pointer-events-none text-white font-sans">
      
      {/* Top Header - Title, Sound toggles & Coin balance */}
      <header className="flex justify-between items-start pointer-events-auto w-full max-w-lg mx-auto">
        <div className="flex gap-2">
          {/* Audio Quick Toggles */}
          <button
            id="toggle-sound-btn"
            onClick={toggleSound}
            className="w-11 h-11 flex items-center justify-center bg-black/60 backdrop-blur-md rounded-full border border-white/10 hover:bg-white/20 active:scale-95 transition-all cursor-pointer"
          >
            {settings.soundEnabled ? <Volume2 className="w-5 h-5 text-cyan-400" /> : <VolumeX className="w-5 h-5 text-gray-500" />}
          </button>
          
          <button
            id="toggle-music-btn"
            onClick={toggleMusic}
            className={`px-3 py-1 h-11 flex items-center justify-center bg-black/60 backdrop-blur-md rounded-full border border-white/10 text-xs font-semibold hover:bg-white/20 active:scale-95 transition-all cursor-pointer ${settings.musicEnabled ? 'text-rose-400' : 'text-gray-500'}`}
          >
            BGM: {settings.musicEnabled ? 'ON' : 'OFF'}
          </button>
        </div>

        {/* Brand details & Coins Balance */}
        <div className="text-right flex flex-col items-end gap-2">
          <div className="flex items-center gap-1.5 text-rose-500 font-bold text-xs tracking-wider bg-rose-500/10 px-2.5 py-1 rounded-full border border-rose-500/20">
            <Flame className="w-3.5 h-3.5 animate-pulse" />
            Endless 3D Highway
          </div>
          <div className="bg-amber-500/15 border border-amber-500/30 px-3 py-1 rounded-full flex items-center gap-1.5 shadow-[0_0_15px_rgba(245,158,11,0.15)] animate-pulse">
            <span className="text-xs">🪙</span>
            <span className="text-xs font-extrabold font-mono text-amber-400">{coins.toLocaleString()} COINS</span>
          </div>
        </div>
      </header>

      {/* Central Screen: Title Banner & Best Scores */}
      <main className="flex flex-col items-center justify-center text-center my-auto pointer-events-auto max-w-lg mx-auto w-full select-none">
        
        {/* Animated Title */}
        <div className="relative mb-6">
          <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-none bg-clip-text text-transparent bg-gradient-to-b from-white via-slate-200 to-slate-400 drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] font-sans uppercase">
            Endless Car <span className="text-rose-500">Racer 3D</span>
          </h1>
          <p className="text-[10px] md:text-xs text-cyan-400 font-mono tracking-[0.25em] mt-1.5 uppercase">
            High Performance HTML5 Simulation
          </p>
        </div>

        {/* Score Board Cards */}
        <div className="grid grid-cols-2 gap-3 w-full mb-8">
          {/* Best Score */}
          <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-3 flex flex-col items-center justify-center">
            <span className="text-[10px] md:text-xs text-gray-400 font-bold uppercase tracking-wider mb-0.5 flex items-center gap-1">
              <Trophy className="w-3 h-3 text-amber-400" /> أفضل نتيجة
            </span>
            <span className="text-xl md:text-2xl font-black text-amber-400 font-mono">
              {highScore.toLocaleString()}
            </span>
          </div>

          {/* Last Score */}
          <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-3 flex flex-col items-center justify-center">
            <span className="text-[10px] md:text-xs text-gray-400 font-bold uppercase tracking-wider mb-0.5">
              آخر نتيجة
            </span>
            <span className="text-xl md:text-2xl font-black text-slate-200 font-mono">
              {lastScore.toLocaleString()}
            </span>
          </div>
        </div>

        {/* MAIN GAMEPLAY OR SHOP ACQUISITION ACTION BUTTON */}
        {!unlockedCarIds.includes(selectedCar.id) ? (
          <button
            id="buy-car-main-btn"
            onClick={() => onBuyCar(selectedCar.id, selectedCar.price || 0)}
            disabled={coins < (selectedCar.price || 0)}
            className={`w-full py-4 px-8 font-black text-lg md:text-xl rounded-2xl border-t transition-all flex items-center justify-center gap-3 cursor-pointer ${
              coins >= (selectedCar.price || 0)
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-[0_8px_30px_rgba(245,158,11,0.4)] border-yellow-300 hover:brightness-110 active:scale-95'
                : 'bg-slate-800 text-slate-500 border-slate-700 cursor-not-allowed opacity-75'
            }`}
          >
            <span>🪙</span>
            <span>شراء السيارة بـ {(selectedCar.price || 0).toLocaleString()}</span>
          </button>
        ) : (
          <button
            id="start-race-btn"
            onClick={onStartGame}
            className="w-full py-4 px-8 bg-gradient-to-r from-rose-600 to-amber-500 text-white font-black text-lg md:text-xl rounded-2xl shadow-[0_8px_30px_rgb(239,68,68,0.4)] border-t border-white/20 hover:from-rose-500 hover:to-amber-400 active:scale-95 transition-all pointer-events-auto flex items-center justify-center gap-3 cursor-pointer group"
          >
            <Play className="w-6 h-6 fill-current group-hover:translate-x-0.5 transition-transform" />
            ابدأ السباق
          </button>
        )}

      </main>

      {/* Bottom Drawer Navigators (Car Selector & Theme selector) */}
      <footer className="w-full max-w-lg mx-auto flex flex-col gap-4 pointer-events-auto">
        
        {/* Secondary Selection Panels depending on activeTab */}
        
        {/* 1. GARAGE CAR SELECTOR PANEL */}
        {activeTab === 'garage' && (
          <div className="bg-black/85 backdrop-blur-lg border border-white/10 rounded-2xl p-4 flex flex-col shadow-2xl animate-in fade-in slide-in-from-bottom-5 duration-200">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                <Car className="w-4 h-4 text-rose-500" /> مرآب السيارات ({currentCarIndex + 1}/16)
              </h3>
              <div className="flex items-center gap-1.5">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                  selectedCar.type === 'supercar' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' :
                  selectedCar.type === 'muscle' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                  selectedCar.type === 'sports' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                  'bg-slate-500/10 text-slate-300 border border-slate-500/20'
                }`}>
                  {selectedCar.type}
                </span>

                {unlockedCarIds.includes(selectedCar.id) ? (
                  <span className="text-[10px] font-bold bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full border border-green-500/30">
                    مفتوحة (Owned)
                  </span>
                ) : (
                  <span className="text-[10px] font-bold bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/30">
                    🪙 {selectedCar.price?.toLocaleString()}
                  </span>
                )}
              </div>
            </div>

            {/* Slider Controls */}
            <div className="flex items-center justify-between mb-4">
              <button onClick={handlePrevCar} className="p-2 hover:bg-white/10 rounded-full transition-colors cursor-pointer">
                <ChevronLeft className="w-6 h-6" />
              </button>
              
              <div className="text-center px-4">
                <h4 className="text-lg font-black text-white tracking-wide">{selectedCar.name}</h4>
                <p className="text-xs text-gray-400 max-w-xs line-clamp-1 mt-0.5">{selectedCar.description}</p>
              </div>

              <button onClick={handleNextCar} className="p-2 hover:bg-white/10 rounded-full transition-colors cursor-pointer">
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            {/* Spec stats bars */}
            <div className="grid grid-cols-3 gap-3 text-xs">
              <div>
                <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                  <span>السرعة</span>
                  <span>{selectedCar.speed}%</span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-400" style={{ width: `${selectedCar.speed}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                  <span>التحكم</span>
                  <span>{selectedCar.handling}%</span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-400" style={{ width: `${selectedCar.handling}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                  <span>التسارع</span>
                  <span>{selectedCar.acceleration}%</span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400" style={{ width: `${selectedCar.acceleration}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. ROAD ROUTE SELECTOR PANEL */}
        {activeTab === 'roads' && (
          <div className="bg-black/85 backdrop-blur-lg border border-white/10 rounded-2xl p-4 flex flex-col shadow-2xl animate-in fade-in slide-in-from-bottom-5 duration-200">
            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2 mb-3">
              <Map className="w-4 h-4 text-rose-500" /> اختر الطريق ({currentRoadIndex + 1}/6)
            </h3>

            <div className="flex items-center justify-between">
              <button onClick={handlePrevRoad} className="p-2 hover:bg-white/10 rounded-full transition-colors cursor-pointer">
                <ChevronLeft className="w-6 h-6" />
              </button>
              
              <div className="text-center px-4">
                <h4 className="text-lg font-black text-amber-400 tracking-wide">{selectedRoad.name}</h4>
                <p className="text-xs text-gray-300 max-w-xs mt-1 leading-relaxed">{selectedRoad.description}</p>
              </div>

              <button onClick={handleNextRoad} className="p-2 hover:bg-white/10 rounded-full transition-colors cursor-pointer">
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          </div>
        )}

        {/* 3. SETTINGS PANEL */}
        {activeTab === 'settings' && (
          <div className="bg-black/85 backdrop-blur-lg border border-white/10 rounded-2xl p-4 flex flex-col gap-4 shadow-2xl animate-in fade-in slide-in-from-bottom-5 duration-200">
            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
              <SettingsIcon className="w-4 h-4 text-rose-500" /> الإعدادات العامة
            </h3>

            {/* Steer Sensitivity */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-300 font-medium">حساسية عجلة القيادة (Steering Sensitivity)</span>
                <span className="text-cyan-400 font-mono font-bold">x{settings.sensitivity.toFixed(1)}</span>
              </div>
              <input
                id="sensitivity-slider"
                type="range"
                min="0.5"
                max="2.0"
                step="0.1"
                value={settings.sensitivity}
                onChange={(e) => onUpdateSettings({ ...settings, sensitivity: parseFloat(e.target.value) })}
                className="w-full accent-cyan-400 bg-white/10 rounded-lg h-1.5 cursor-pointer"
              />
            </div>

            {/* Graphics Selector */}
            <div className="flex justify-between items-center text-xs pt-1">
              <span className="text-gray-300 font-medium">جودة الجرافيك (Graphics Quality)</span>
              <div className="flex bg-white/5 p-1 rounded-lg border border-white/10">
                {(['low', 'medium', 'high'] as const).map((q) => (
                  <button
                    key={q}
                    onClick={() => onUpdateSettings({ ...settings, graphicsQuality: q })}
                    className={`px-3 py-1 rounded-md uppercase font-bold text-[10px] transition-colors cursor-pointer ${
                      settings.graphicsQuality === q
                        ? 'bg-rose-500 text-white shadow-md'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    {q === 'low' ? 'منخفض' : q === 'medium' ? 'متوسط' : 'عالي'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Bottom Horizontal Menu Dock */}
        <div className="grid grid-cols-3 gap-2 bg-black/60 backdrop-blur-md p-1.5 rounded-2xl border border-white/10">
          <button
            id="menu-tab-garage"
            onClick={() => setActiveTab(activeTab === 'garage' ? 'none' : 'garage')}
            className={`py-3 flex flex-col items-center justify-center rounded-xl transition-all gap-1 cursor-pointer ${activeTab === 'garage' ? 'bg-white/10 text-rose-400' : 'text-gray-300 hover:bg-white/5'}`}
          >
            <Car className="w-5 h-5" />
            <span className="text-[10px] font-bold">تغيير السيارة</span>
          </button>

          <button
            id="menu-tab-roads"
            onClick={() => setActiveTab(activeTab === 'roads' ? 'none' : 'roads')}
            className={`py-3 flex flex-col items-center justify-center rounded-xl transition-all gap-1 cursor-pointer ${activeTab === 'roads' ? 'bg-white/10 text-rose-400' : 'text-gray-300 hover:bg-white/5'}`}
          >
            <Map className="w-5 h-5" />
            <span className="text-[10px] font-bold">تغيير الطريق</span>
          </button>

          <button
            id="menu-tab-settings"
            onClick={() => setActiveTab(activeTab === 'settings' ? 'none' : 'settings')}
            className={`py-3 flex flex-col items-center justify-center rounded-xl transition-all gap-1 cursor-pointer ${activeTab === 'settings' ? 'bg-white/10 text-rose-400' : 'text-gray-300 hover:bg-white/5'}`}
          >
            <SettingsIcon className="w-5 h-5" />
            <span className="text-[10px] font-bold">الإعدادات</span>
          </button>
        </div>

      </footer>
    </div>
  );
};

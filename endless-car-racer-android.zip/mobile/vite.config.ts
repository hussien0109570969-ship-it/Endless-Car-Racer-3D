import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";

// Standalone static SPA build for the offline APK (Capacitor).
// Does NOT use TanStack Start / SSR. Output goes to dist-mobile/ at repo root.
export default defineConfig({
  root: __dirname,
  base: "./", // relative asset paths so file:// works inside the APK webview
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: { "@": path.resolve(__dirname, "../src") },
  },
  build: {
    outDir: path.resolve(__dirname, "../dist-mobile"),
    emptyOutDir: true,
    target: "es2020",
    sourcemap: false,
  },
});

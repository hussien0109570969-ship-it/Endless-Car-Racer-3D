# بناء ملف APK (Endless Car Racer 3D)

Lovable لا يستطيع بناء APK داخل السحابة (لا يوجد Android SDK / Gradle / JDK في بيئته). المشروع الآن جاهز بحيث تبنيه محلياً على جهازك بأمرين.

## المتطلبات لمرة واحدة
- Node.js 20+ و npm/bun
- **Android Studio** مثبّت (يجلب Android SDK + JDK 17 تلقائياً)
- متغير البيئة `ANDROID_HOME` مضبوط على مسار SDK (عادةً `~/Library/Android/sdk` أو `%LOCALAPPDATA%\Android\Sdk`)

## الخطوات

```bash
# 1) تثبيت الاعتماديات (مرة واحدة)
bun install
bun add -d @capacitor/cli
bun add @capacitor/core @capacitor/android

# 2) بناء واجهة الويب الثابتة (تخرج في dist-mobile/)
bun run build:mobile

# 3) إنشاء مشروع Android (مرة واحدة فقط)
npx cap add android

# 4) في كل مرة تعدل فيها اللعبة:
bun run build:mobile && npx cap sync android

# 5) بناء APK للتثبيت المباشر
cd android
./gradlew assembleDebug
```

ملف APK النهائي:
```
android/app/build/outputs/apk/debug/app-debug.apk
```
انقله للهاتف وثبته (فعّل "تثبيت من مصادر غير معروفة").

## للنسخة الموقّعة للنشر
```bash
cd android
./gradlew assembleRelease
```
ثم وقّع الـ APK بمفتاحك (`keytool` + `apksigner`).

## ملاحظات
- التطبيق **يعمل بالكامل بدون إنترنت** — جميع الملفات مدمجة داخل APK.
- بيانات اللاعب (العملات، أفضل نتيجة، السيارات، الإعدادات) تُحفظ في `localStorage` داخل WebView.
- لا يوجد أي منطق تحديث/تحقق من الإصدار في الكود.
- نسخة الويب على Lovable (`open-fix-deploy.lovable.app`) تبقى تعمل كما هي.
